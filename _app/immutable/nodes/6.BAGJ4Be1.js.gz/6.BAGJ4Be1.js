import{c as e,a as n}from"../chunks/6dxegI5I.js";export{e as component,n as universal};
