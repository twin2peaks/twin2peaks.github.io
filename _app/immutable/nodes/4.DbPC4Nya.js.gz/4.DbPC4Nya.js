import{a as e,_ as n}from"../chunks/i8cRU_aK.js";export{e as component,n as universal};
