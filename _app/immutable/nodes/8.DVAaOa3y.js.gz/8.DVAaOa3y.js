import{a as e,_ as n}from"../chunks/C8oGfaaL.js";export{e as component,n as universal};
