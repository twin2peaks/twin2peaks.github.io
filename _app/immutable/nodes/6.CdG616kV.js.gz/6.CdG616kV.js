import{a as e,_ as n}from"../chunks/CxVgzuN-.js";export{e as component,n as universal};
