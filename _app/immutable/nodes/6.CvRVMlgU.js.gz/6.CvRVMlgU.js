import{a as e,_ as n}from"../chunks/DyrMymoX.js";export{e as component,n as universal};
