import{a as e,_ as n}from"../chunks/CW0GOvLp.js";export{e as component,n as universal};
