import{a as e,_ as n}from"../chunks/v89m_HWY.js";export{e as component,n as universal};
