import{a as e,_ as n}from"../chunks/CDhdnOu3.js";export{e as component,n as universal};
