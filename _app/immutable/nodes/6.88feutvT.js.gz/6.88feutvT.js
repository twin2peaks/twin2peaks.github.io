import{c as e,a as n}from"../chunks/BTZdUwbV.js";export{e as component,n as universal};
