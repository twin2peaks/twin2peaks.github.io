import{a as e,_ as n}from"../chunks/DqcPfCLD.js";export{e as component,n as universal};
