import{a as e,_ as n}from"../chunks/5E9Idw6X.js";export{e as component,n as universal};
