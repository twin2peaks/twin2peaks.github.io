import{a as e,_ as n}from"../chunks/BCghn0cw.js";export{e as component,n as universal};
