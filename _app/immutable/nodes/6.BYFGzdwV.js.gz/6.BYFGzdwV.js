import{a as e,_ as n}from"../chunks/D3_Lbiiu.js";export{e as component,n as universal};
