import{a as e,_ as n}from"../chunks/B9ACP4se.js";export{e as component,n as universal};
