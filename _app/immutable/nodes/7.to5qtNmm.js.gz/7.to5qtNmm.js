import{a as e,_ as n}from"../chunks/Cs8R2i-y.js";export{e as component,n as universal};
