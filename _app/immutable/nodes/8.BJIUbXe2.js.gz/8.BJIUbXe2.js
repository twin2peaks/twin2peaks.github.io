import{a as e,_ as n}from"../chunks/D05wD5I0.js";export{e as component,n as universal};
