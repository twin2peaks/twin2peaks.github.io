import{c as e,a as n}from"../chunks/BYtskV3H.js";export{e as component,n as universal};
