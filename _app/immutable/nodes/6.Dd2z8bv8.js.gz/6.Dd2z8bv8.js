import{a as e,_ as n}from"../chunks/C40_waQG.js";export{e as component,n as universal};
