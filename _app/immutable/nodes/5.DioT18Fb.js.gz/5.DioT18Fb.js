import"../chunks/CWj6FrbW.js";import{a as $e,C as yt,b as Ae,s as Ve,r as Vn}from"../chunks/guWAzMQv.js";import{s as P,c as zn,o as Ms}from"../chunks/92BxO-YI.js";import{p as we,J as ze,b as q,a as v,w as Ie,f as T,r as f,s as g,v as h,t as R,l as ne,i as $,m as ee,j as K,k as c,o as De,aZ as Fn,G as ae,aH as ce,q as ke,u as W,F as Ds,au as Ns,aG as qe}from"../chunks/B17SWd1h.js";import{l as Q,p as E,i as N,b as Wn,s as jn,a as qn}from"../chunks/CbBjHLQM.js";import{b as Ls,i as Re,s as Ke,e as kt,a as Lt}from"../chunks/CJm_Zloh.js";import{c as dr}from"../chunks/W2OxLYGC.js";import{b as es}from"../chunks/vBNkJYKM.js";import{p as Us,T as Le,c as Tr,B as st,M as Gn,D as Kn}from"../chunks/DLpX6n0z.js";import{b as he}from"../chunks/D9TEKe4g.js";import{e as oe}from"../chunks/B8IG3RFS.js";import{b as Mt}from"../chunks/D84R_cOR.js";import{I as ts}from"../chunks/DQkK7CaC.js";import{C as Yn,b as Jn,a as Hs,W as Bs}from"../chunks/BpbV__he.js";import{s as Zn}from"../chunks/t8KIAnaI.js";import{a as Qn,R as Se,C as se,G as rs}from"../chunks/DwUZ0vKa.js";import{S as Vr,D as Vs}from"../chunks/BryTQtM9.js";import{T as Zt,b as Xn}from"../chunks/CVt1_1e6.js";var ei=T("<div><!></div>"),ti=T("<a><!> <!></a>"),ri=T("<div><!></div>"),si=T("<a><!> <!></a>");function Bt(r,e){const t=Ls(e),s=Q(e,["children","$$slots","$$events","$$legacy"]),n=Q(s,["size","href","inline","icon","disabled","visited","ref"]);we(e,!1);let i=E(e,"size",8,void 0),a=E(e,"href",8,void 0),o=E(e,"inline",8,!1),l=E(e,"icon",8,void 0),u=E(e,"disabled",8,!1),m=E(e,"visited",8,!1),p=E(e,"ref",12,null);Re();var d=ze(),_=q(d);{var y=I=>{var w=ti();$e(w,b=>({role:"link","aria-disabled":"true",...n,[yt]:b}),[()=>({"bx--link":!0,"bx--link--disabled":u(),"bx--link--inline":o(),"bx--link--visited":m()})]);var S=f(w);Ke(S,e,"default",{},null);var M=g(S,2);{var O=b=>{var j=ei();Ae(j,1,"",null,{},{"bx--link__icon":!0});var V=f(j);Ke(V,e,"icon",{},H=>{var A=ze(),k=q(A);dr(k,l,(B,U)=>{U(B,{})}),v(H,A)}),h(j),v(b,j)};N(M,b=>{!o()&&(t.icon||l())&&b(O)})}h(w),Mt(w,b=>p(b),()=>p()),oe("click",w,function(b){he.call(this,e,b)}),oe("mouseover",w,function(b){he.call(this,e,b)}),oe("mouseenter",w,function(b){he.call(this,e,b)}),oe("mouseleave",w,function(b){he.call(this,e,b)}),v(I,w)},C=I=>{var w=si();$e(w,b=>({rel:n.target==="_blank"?"noopener noreferrer":void 0,href:a(),...n,[yt]:b}),[()=>({"bx--link":!0,"bx--link--disabled":u(),"bx--link--inline":o(),"bx--link--visited":m(),"bx--link--sm":i()==="sm","bx--link--lg":i()==="lg"})]);var S=f(w);Ke(S,e,"default",{},null);var M=g(S,2);{var O=b=>{var j=ri();Ae(j,1,"",null,{},{"bx--link__icon":!0});var V=f(j);Ke(V,e,"icon",{},H=>{var A=ze(),k=q(A);dr(k,l,(B,U)=>{U(B,{})}),v(H,A)}),h(j),v(b,j)};N(M,b=>{!o()&&(t.icon||l())&&b(O)})}h(w),Mt(w,b=>p(b),()=>p()),oe("click",w,function(b){he.call(this,e,b)}),oe("mouseover",w,function(b){he.call(this,e,b)}),oe("mouseenter",w,function(b){he.call(this,e,b)}),oe("mouseleave",w,function(b){he.call(this,e,b)}),v(I,w)};N(_,I=>{u()?I(y):I(C,!1)})}v(r,d),Ie()}var ni=T("<div> </div>"),ii=T("<div> </div>"),ai=T("<div><!></div> <!> <!>",1);function oi(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","type","open","light","disabled","invalid","invalidText","warn","warnText"]);let n=E(e,"size",8,void 0),i=E(e,"type",8,"default"),a=E(e,"open",8,!1),o=E(e,"light",8,!1),l=E(e,"disabled",8,!1),u=E(e,"invalid",8,!1),m=E(e,"invalidText",8,""),p=E(e,"warn",8,!1),d=E(e,"warnText",8,"");var _=ai(),y=q(_);$e(y,O=>({role:"listbox",tabindex:"-1","data-invalid":u()||void 0,...s,[yt]:O}),[()=>({"bx--list-box":!0,"bx--list-box--sm":n()==="sm","bx--list-box--xl":n()==="xl","bx--list-box--inline":i()==="inline","bx--list-box--disabled":l(),"bx--list-box--expanded":a(),"bx--list-box--light":o(),"bx--list-box--warning":!u()&&p()})]);var C=f(y);Ke(C,e,"default",{},null),h(y);var I=g(y,2);{var w=O=>{var b=ni();Ae(b,1,"",null,{},{"bx--form-requirement":!0});var j=f(b,!0);h(b),R(()=>P(j,m())),v(O,b)};N(I,O=>{u()&&O(w)})}var S=g(I,2);{var M=O=>{var b=ii();Ae(b,1,"",null,{},{"bx--form-requirement":!0});var j=f(b,!0);h(b),R(()=>P(j,d())),v(O,b)};N(S,O=>{!u()&&p()&&O(M)})}oe("keydown",y,function(O){he.call(this,e,O)}),oe("keydown",y,O=>{O.key==="Escape"&&O.stopPropagation()}),oe("click",y,Us(function(O){he.call(this,e,O)})),v(r,_)}var li=T("<div><!></div>");function ci(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["id","ref"]);we(e,!1);let n=E(e,"id",24,()=>"ccs-"+Math.random().toString(36)),i=E(e,"ref",12,null);Re();var a=li();$e(a,()=>({role:"listbox",id:`menu-${n()??""}`,...s,[yt]:{"bx--list-box__menu":!0}}));var o=f(a);Ke(o,e,"default",{},null),h(a),Mt(a,l=>i(l),()=>i()),oe("scroll",a,function(l){he.call(this,e,l)}),v(r,a),Ie()}var di=T("<div><!></div>");function ui(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["translationIds","open","translateWithId"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"open",8,!1);const o={close:"close",open:"open"};let l=E(e,"translateWithId",8,d=>u[d]);const u={[o.close]:"Close menu",[o.open]:"Open menu"};ne(()=>K(a()),()=>{$(n,a()?o.close:o.open)}),ne(()=>(K(l()),c(n)),()=>{var d;$(i,((d=l())==null?void 0:d(c(n)))??u[c(n)])}),De(),Re();var m=di();$e(m,d=>({...s,[yt]:d}),[()=>({"bx--list-box__menu-icon":!0,"bx--list-box__menu-icon--open":a()})]);var p=f(m);return Yn(p,{get"aria-label"(){return c(i)},get title(){return c(i)}}),h(m),oe("click",m,Us(function(d){he.call(this,e,d)})),v(r,m),Jn(e,"translationIds",o),Ie({translationIds:o})}var hi=T("<div><div><!></div></div>");function fi(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["active","highlighted","disabled"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"active",8,!1),o=E(e,"highlighted",8,!1),l=E(e,"disabled",8,!1),u=ee(null);ne(()=>c(u),()=>{var _,y;$(n,((_=c(u))==null?void 0:_.offsetWidth)<((y=c(u))==null?void 0:y.scrollWidth))}),ne(()=>(c(n),c(u)),()=>{var _;$(i,c(n)?(_=c(u))==null?void 0:_.innerText:void 0)}),ne(()=>(K(o()),c(u)),()=>{o()&&c(u)&&!c(u).matches(":hover")&&c(u).scrollIntoView({block:"nearest"})}),De();var m=hi();$e(m,_=>({role:"option",tabindex:"-1","aria-selected":a(),"aria-disabled":l()?!0:void 0,disabled:l()?!0:void 0,...s,[yt]:_}),[()=>({"bx--list-box__menu-item":!0,"bx--list-box__menu-item--active":a(),"bx--list-box__menu-item--highlighted":o()||a()})]);var p=f(m);Ae(p,1,"",null,{},{"bx--list-box__menu-item__option":!0});var d=f(p);Ke(d,e,"default",{},null),h(p),Mt(p,_=>$(u,_),()=>c(u)),h(m),R(()=>Ve(p,"title",c(i))),oe("click",m,function(_){he.call(this,e,_)}),oe("mouseenter",m,function(_){he.call(this,e,_)}),oe("mouseleave",m,function(_){he.call(this,e,_)}),v(r,m),Ie()}var vi=T("<label> </label>"),pi=T('<!> <!> <button type="button" tabindex="0"><span><!></span> <!></button> <!>',1),gi=T("<div> </div>"),mi=T("<div><!> <!> <!></div>");function _i(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["items","itemToString","selectedId","type","direction","size","open","light","disabled","titleText","invalid","invalidText","warn","warnText","helperText","label","hideLabel","translateWithId","id","name","ref"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"items",24,()=>[]),o=E(e,"itemToString",8,ue=>ue.text||ue.id),l=E(e,"selectedId",12),u=E(e,"type",8,"default"),m=E(e,"direction",8,"bottom"),p=E(e,"size",8,void 0),d=E(e,"open",12,!1),_=E(e,"light",8,!1),y=E(e,"disabled",8,!1),C=E(e,"titleText",8,""),I=E(e,"invalid",8,!1),w=E(e,"invalidText",8,""),S=E(e,"warn",8,!1),M=E(e,"warnText",8,""),O=E(e,"helperText",8,""),b=E(e,"label",8,void 0),j=E(e,"hideLabel",8,!1),V=E(e,"translateWithId",8,void 0),H=E(e,"id",24,()=>"ccs-"+Math.random().toString(36)),A=E(e,"name",8,void 0),k=E(e,"ref",12,null);const B=zn();let U=ee(-1);function F(ue){let re=c(U)+ue;if(a().length===0)return;re<0?re=a().length-1:re>=a().length&&(re=0);let Ne=a()[re].disabled;for(;Ne;)re=re+ue,re<0?re=a().length-1:re>=a().length&&(re=0),Ne=a()[re].disabled;$(U,re)}const L=()=>{B("select",{selectedId:l(),selectedItem:a().find(ue=>ue.id===l())})},x=({target:ue})=>{d()&&k()&&!k().contains(ue)&&d(!1)};Ms(()=>(parent&&parent.addEventListener("click",x),()=>{parent&&parent.removeEventListener("click",x)})),ne(()=>K(u()),()=>{$(n,u()==="inline")}),ne(()=>(K(a()),K(l())),()=>{$(i,a().find(ue=>ue.id===l()))}),ne(()=>K(d()),()=>{d()||$(U,-1)}),De(),Re();var z=mi();oe("click",Fn,x),$e(z,ue=>({...s,[yt]:ue}),[()=>({"bx--dropdown__wrapper":!0,"bx--list-box__wrapper":!0,"bx--dropdown__wrapper--inline":c(n),"bx--list-box__wrapper--inline":c(n),"bx--dropdown__wrapper--inline--invalid":c(n)&&I()})]);var fe=f(z);{var ye=ue=>{var re=vi();let Ne;var We=f(re,!0);h(re),R(tt=>{Ve(re,"for",H()),Ne=Ae(re,1,"",null,Ne,tt),P(We,C())},[()=>({"bx--label":!0,"bx--label--disabled":y(),"bx--visually-hidden":j()})],ae),v(ue,re)};N(fe,ue=>{C()&&ue(ye)})}var J=g(fe,2);const te=ae(()=>m()==="top"&&"bx--list-box--up"),le=ae(()=>I()&&"bx--dropdown--invalid"),de=ae(()=>!I()&&S()&&"bx--dropdown--warning"),X=ae(()=>d()&&"bx--dropdown--open"),ve=ae(()=>p()==="sm"&&"bx--dropdown--sm"),Te=ae(()=>p()==="xl"&&"bx--dropdown--xl"),Pe=ae(()=>c(n)&&"bx--dropdown--inline"),pe=ae(()=>y()&&"bx--dropdown--disabled"),xe=ae(()=>_()&&"bx--dropdown--light");oi(J,{role:void 0,get type(){return u()},get size(){return p()},get name(){return A()},get"aria-label"(){return t["aria-label"]},get class(){return`bx--dropdown 
      ${c(te)??""} 
      ${c(le)??""} 
      ${c(de)??""} 
      ${c(X)??""}
      ${c(ve)??""}
      ${c(Te)??""}
      ${c(Pe)??""}
      ${c(pe)??""}
      ${c(xe)??""}`},get disabled(){return y()},get open(){return d()},get invalid(){return I()},get invalidText(){return w()},get light(){return _()},get warn(){return S()},get warnText(){return M()},$$events:{click:({target:ue})=>{y()||d(k().contains(ue)?!d():!1)}},children:(ue,re)=>{var Ne=pi(),We=q(Ne);{var tt=ie=>{Hs(ie,{class:"bx--list-box__invalid-icon"})};N(We,ie=>{I()&&ie(tt)})}var rt=g(We,2);{var Ht=ie=>{Bs(ie,{class:"bx--list-box__invalid-icon bx--list-box__invalid-icon--warning"})};N(rt,ie=>{!I()&&S()&&ie(Ht)})}var Oe=g(rt,2);Ae(Oe,1,"",null,{},{"bx--list-box__field":!0});var ht=f(Oe);Ae(ht,1,"",null,{},{"bx--list-box__label":!0});var D=f(ht);{var Z=ie=>{var me=ce();R(Y=>P(me,Y),[()=>o()(c(i))],ae),v(ie,me)},ge=ie=>{var me=ce();R(()=>P(me,b())),v(ie,me)};N(D,ie=>{c(i)?ie(Z):ie(ge,!1)})}h(ht);var Ue=g(ht,2);ui(Ue,{get translateWithId(){return V()},get open(){return d()},$$events:{click:ie=>{ie.stopPropagation(),!y()&&d(!d())}}}),h(Oe),Mt(Oe,ie=>k(ie),()=>k());var He=g(Oe,2);{var je=ie=>{ci(ie,{get"aria-labelledby"(){return H()},get id(){return H()},children:(me,Y)=>{var Ee=ze(),Ce=q(Ee);kt(Ce,3,a,Me=>Me.id,(Me,Ze,Qe)=>{const Et=ae(()=>l()===c(Ze).id),Ln=ae(()=>c(U)===c(Qe));fi(Me,{get id(){return c(Ze).id},get active(){return c(Et)},get highlighted(){return c(Ln)},get disabled(){return c(Ze).disabled},$$events:{click:Er=>{if(c(Ze).disabled){Er.stopPropagation();return}l(c(Ze).id),L(),k().focus()},mouseenter:()=>{c(Ze).disabled||$(U,c(Qe))}},children:(Er,Ku)=>{var Qr=ze(),Un=q(Qr);Ke(Un,e,"default",{get item(){return c(Ze)},get index(){return c(Qe)}},Hn=>{var Xr=ce();R(Bn=>P(Xr,Bn),[()=>o()(c(Ze))],ae),v(Hn,Xr)}),v(Er,Qr)},$$slots:{default:!0}})}),v(me,Ee)},$$slots:{default:!0}})};N(He,ie=>{d()&&ie(je)})}R(()=>{Ve(Oe,"aria-expanded",d()),Oe.disabled=y(),Ve(Oe,"translatewithid",V()),Ve(Oe,"id",H())}),oe("keydown",Oe,ie=>{const{key:me}=ie;["Enter","ArrowDown","ArrowUp"].includes(me)&&ie.preventDefault(),me==="Enter"?(d(!d()),c(U)>-1&&a()[c(U)].id!==l()&&(l(a()[c(U)].id),L(),d(!1))):me==="Tab"?d(!1):me==="ArrowDown"?(d()||d(!0),F(1)):me==="ArrowUp"?(d()||d(!0),F(-1)):me==="Escape"&&d(!1)}),oe("keyup",Oe,ie=>{const{key:me}=ie;if([" "].includes(me))ie.preventDefault();else return;d(!d()),c(U)>-1&&a()[c(U)].id!==l()&&(l(a()[c(U)].id),L(),d(!1))}),v(ue,Ne)},$$slots:{default:!0}});var _e=g(J,2);{var Fe=ue=>{var re=gi();let Ne;var We=f(re,!0);h(re),R(tt=>{Ne=Ae(re,1,"",null,Ne,tt),P(We,O())},[()=>({"bx--form__helper-text":!0,"bx--form__helper-text--disabled":y()})],ae),v(ue,re)};N(_e,ue=>{!c(n)&&!I()&&!S()&&O()&&ue(Fe)})}h(z),v(r,z),Ie()}var bi=ke("<title> </title>"),yi=ke('<svg><!><path d="M30.94,15.66A16.69,16.69,0,0,0,16,5,16.69,16.69,0,0,0,1.06,15.66a1,1,0,0,0,0,.68A16.69,16.69,0,0,0,16,27,16.69,16.69,0,0,0,30.94,16.34,1,1,0,0,0,30.94,15.66ZM16,25c-5.3,0-10.9-3.93-12.93-9C5.1,10.93,10.7,7,16,7s10.9,3.93,12.93,9C26.9,21.07,21.3,25,16,25Z"></path><path d="M16,10a6,6,0,1,0,6,6A6,6,0,0,0,16,10Zm0,10a4,4,0,1,1,4-4A4,4,0,0,1,16,20Z"></path></svg>');function wi(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=yi();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=bi(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var Ii=ke("<title> </title>"),Ei=ke('<svg><!><path d="M5.24,22.51l1.43-1.42A14.06,14.06,0,0,1,3.07,16C5.1,10.93,10.7,7,16,7a12.38,12.38,0,0,1,4,.72l1.55-1.56A14.72,14.72,0,0,0,16,5,16.69,16.69,0,0,0,1.06,15.66a1,1,0,0,0,0,.68A16,16,0,0,0,5.24,22.51Z"></path><path d="M12 15.73a4 4 0 013.7-3.7l1.81-1.82a6 6 0 00-7.33 7.33zM30.94 15.66A16.4 16.4 0 0025.2 8.22L30 3.41 28.59 2 2 28.59 3.41 30l5.1-5.1A15.29 15.29 0 0016 27 16.69 16.69 0 0030.94 16.34 1 1 0 0030.94 15.66zM20 16a4 4 0 01-6 3.44L19.44 14A4 4 0 0120 16zm-4 9a13.05 13.05 0 01-6-1.58l2.54-2.54a6 6 0 008.35-8.35l2.87-2.87A14.54 14.54 0 0128.93 16C26.9 21.07 21.3 25 16 25z"></path></svg>');function Ti(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=Ei();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=Ii(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var Pi=T("<div> </div>"),xi=T("<label><!></label> <!>",1),ki=T("<label><!></label>"),Ai=T('<hr class="bx--text-input__divider"/> <div class="bx--form-requirement"> </div>',1),Si=T("<span><!></span>"),Ci=T('<button type="button"><!> <!></button>'),$i=T("<div> </div>"),Ri=T("<div> </div>"),Oi=T("<div> </div>"),Mi=T("<div><!> <!> <div><div><!> <!> <input/> <!> <!></div> <!> <!> <!></div></div>");function Pr(r,e){const t=Ls(e),s=Q(e,["children","$$slots","$$events","$$legacy"]),n=Q(s,["size","value","type","placeholder","hidePasswordLabel","showPasswordLabel","tooltipAlignment","tooltipPosition","light","disabled","helperText","labelText","hideLabel","invalid","invalidText","warn","warnText","inline","id","name","ref"]);we(e,!1);const i=ee(),a=ee(),o=ee();let l=E(e,"size",8,void 0),u=E(e,"value",12,""),m=E(e,"type",12,"password"),p=E(e,"placeholder",8,""),d=E(e,"hidePasswordLabel",8,"Hide password"),_=E(e,"showPasswordLabel",8,"Show password"),y=E(e,"tooltipAlignment",8,"center"),C=E(e,"tooltipPosition",8,"bottom"),I=E(e,"light",8,!1),w=E(e,"disabled",8,!1),S=E(e,"helperText",8,""),M=E(e,"labelText",8,""),O=E(e,"hideLabel",8,!1),b=E(e,"invalid",8,!1),j=E(e,"invalidText",8,""),V=E(e,"warn",8,!1),H=E(e,"warnText",8,""),A=E(e,"inline",8,!1),k=E(e,"id",24,()=>"ccs-"+Math.random().toString(36)),B=E(e,"name",8,void 0),U=E(e,"ref",12,null);const F=Ds("Form"),L=!!F&&F.isFluid;ne(()=>K(k()),()=>{$(i,`helper-${k()}`)}),ne(()=>K(k()),()=>{$(a,`error-${k()}`)}),ne(()=>K(k()),()=>{$(o,`warn-${k()}`)}),De(),Re();var x=Mi();let z;var fe=f(x);{var ye=D=>{var Z=xi(),ge=q(Z);let Ue;var He=f(ge);Ke(He,e,"labelText",{},me=>{var Y=ce();R(()=>P(Y,M())),v(me,Y)}),h(ge);var je=g(ge,2);{var ie=me=>{var Y=Pi();let Ee;var Ce=f(Y,!0);h(Y),R(Me=>{Ve(Y,"id",c(i)),Ee=Ae(Y,1,"",null,Ee,Me),P(Ce,S())},[()=>({"bx--form__helper-text":!0,"bx--form__helper-text--disabled":w(),"bx--form__helper-text--inline":A()})],ae),v(me,Y)};N(je,me=>{!L&&S()&&me(ie)})}R(me=>{Ve(ge,"for",k()),Ue=Ae(ge,1,"",null,Ue,me)},[()=>({"bx--label":!0,"bx--visually-hidden":O(),"bx--label--disabled":w(),"bx--label--inline":A(),"bx--label--inline--sm":A()&&l()==="sm","bx--label--inline--xl":A()&&l()==="xl"})],ae),v(D,Z)};N(fe,D=>{A()&&D(ye)})}var J=g(fe,2);{var te=D=>{var Z=ki();let ge;var Ue=f(Z);Ke(Ue,e,"labelText",{},He=>{var je=ce();R(()=>P(je,M())),v(He,je)}),h(Z),R(He=>{Ve(Z,"for",k()),ge=Ae(Z,1,"",null,ge,He)},[()=>({"bx--label":!0,"bx--visually-hidden":O(),"bx--label--disabled":w(),"bx--label--inline":A(),"bx--label--inline--sm":A()&&l()==="sm","bx--label--inline--xl":A()&&l()==="xl"})],ae),v(D,Z)};N(J,D=>{!A()&&(M()||t.labelText)&&D(te)})}var le=g(J,2);let de;var X=f(le);let ve;var Te=f(X);{var Pe=D=>{Hs(D,{class:"bx--text-input__invalid-icon"})};N(Te,D=>{b()&&D(Pe)})}var pe=g(Te,2);{var xe=D=>{Bs(D,{class:`bx--text-input__invalid-icon
            bx--text-input__invalid-icon--warning`})};N(pe,D=>{!b()&&V()&&D(xe)})}var _e=g(pe,2);Vn(_e),$e(_e,D=>({"data-invalid":b()||void 0,"aria-invalid":b()||void 0,"aria-describedby":b()?c(a):V()?c(o):S()?c(i):void 0,id:k(),name:B(),placeholder:p(),type:m(),value:u()??"",disabled:w(),...n,[yt]:D}),[()=>({"bx--text-input":!0,"bx--password-input":!0,"bx--text-input--light":I(),"bx--text-input--invalid":b(),"bx--text-input--warning":V(),"bx--text-input--sm":l()==="sm","bx--text-input--xl":l()==="xl"})]),Mt(_e,D=>U(D),()=>U());var Fe=g(_e,2);{var ue=D=>{var Z=Ai(),ge=g(q(Z),2),Ue=f(ge,!0);h(ge),R(()=>{Ve(ge,"id",c(a)),P(Ue,j())}),v(D,Z)};N(Fe,D=>{L&&b()&&D(ue)})}var re=g(Fe,2);{var Ne=D=>{var Z=Ci();let ge;var Ue=f(Z);{var He=Y=>{var Ee=Si();Ae(Ee,1,"",null,{},{"bx--assistive-text":!0});var Ce=f(Ee);{var Me=Qe=>{var Et=ce();R(()=>P(Et,d())),v(Qe,Et)},Ze=Qe=>{var Et=ce();R(()=>P(Et,_())),v(Qe,Et)};N(Ce,Qe=>{m()==="text"?Qe(Me):Qe(Ze,!1)})}h(Ee),v(Y,Ee)};N(Ue,Y=>{w()||Y(He)})}var je=g(Ue,2);{var ie=Y=>{Ti(Y,{class:"bx--icon-visibility-off"})},me=Y=>{wi(Y,{class:"bx--icon-visibility-on"})};N(je,Y=>{m()==="text"?Y(ie):Y(me,!1)})}h(Z),R(Y=>{Z.disabled=w(),ge=Ae(Z,1,"",null,ge,Y)},[()=>({"bx--text-input--password__visibility__toggle":!0,"bx--btn":!0,"bx--btn--icon-only":!0,"bx--btn--disabled":w(),"bx--tooltip__trigger":!0,"bx--tooltip--a11y":!0,"bx--tooltip--top":C()==="top","bx--tooltip--right":C()==="right","bx--tooltip--bottom":C()==="bottom","bx--tooltip--left":C()==="left","bx--tooltip--align-start":y()==="start","bx--tooltip--align-center":y()==="center","bx--tooltip--align-end":y()==="end"})],ae),oe("click",Z,()=>{m(m()==="password"?"text":"password")}),v(D,Z)};N(re,D=>{L&&b()||D(Ne)})}h(X);var We=g(X,2);{var tt=D=>{var Z=$i();Ae(Z,1,"",null,{},{"bx--form-requirement":!0});var ge=f(Z,!0);h(Z),R(()=>{Ve(Z,"id",c(a)),P(ge,j())}),v(D,Z)};N(We,D=>{!L&&b()&&D(tt)})}var rt=g(We,2);{var Ht=D=>{var Z=Ri();let ge;var Ue=f(Z,!0);h(Z),R(He=>{ge=Ae(Z,1,"",null,ge,He),P(Ue,S())},[()=>({"bx--form__helper-text":!0,"bx--form__helper-text--disabled":w(),"bx--form__helper-text--inline":A()})],ae),v(D,Z)};N(rt,D=>{!b()&&!V()&&!L&&!A()&&S()&&D(Ht)})}var Oe=g(rt,2);{var ht=D=>{var Z=Oi();Ae(Z,1,"",null,{},{"bx--form-requirement":!0});var ge=f(Z,!0);h(Z),R(()=>{Ve(Z,"id",c(o)),P(ge,H())}),v(D,Z)};N(Oe,D=>{!L&&!b()&&V()&&D(ht)})}h(le),h(x),R((D,Z,ge)=>{z=Ae(x,1,"",null,z,D),de=Ae(le,1,"",null,de,Z),Ve(X,"data-invalid",b()||void 0),ve=Ae(X,1,"",null,ve,ge)},[()=>({"bx--form-item":!0,"bx--text-input-wrapper":!0,"bx--password-input-wrapper":!L,"bx--text-input-wrapper--light":I(),"bx--text-input-wrapper--inline":A()}),()=>({"bx--text-input__field-outer-wrapper":!0,"bx--text-input__field-outer-wrapper--inline":A()}),()=>({"bx--text-input__field-wrapper":!0,"bx--text-input__field-wrapper--warning":V()})],ae),oe("change",_e,function(D){he.call(this,e,D)}),oe("input",_e,function(D){he.call(this,e,D)}),oe("input",_e,({target:D})=>{u(D.value)}),oe("keydown",_e,function(D){he.call(this,e,D)}),oe("keyup",_e,function(D){he.call(this,e,D)}),oe("focus",_e,function(D){he.call(this,e,D)}),oe("blur",_e,function(D){he.call(this,e,D)}),oe("paste",_e,function(D){he.call(this,e,D)}),oe("click",x,function(D){he.call(this,e,D)}),oe("mouseover",x,function(D){he.call(this,e,D)}),oe("mouseenter",x,function(D){he.call(this,e,D)}),oe("mouseleave",x,function(D){he.call(this,e,D)}),v(r,x),Ie()}function Ft(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["clicked","light","disabled","href"]);we(e,!1);let n=E(e,"clicked",12,!1),i=E(e,"light",8,!1),a=E(e,"disabled",8,!1),o=E(e,"href",8,void 0);Re();const l=ae(()=>n()&&"bx--tile--is-clicked"),u=ae(()=>i()&&"bx--tile--light"),m=ae(()=>s.class);Bt(r,Wn(()=>s,{get disabled(){return a()},get class(){return`bx--tile bx--tile--clickable ${c(l)??""} ${c(u)??""} ${c(m)??""}`},get href(){return o()},$$events:{click:[function(p){he.call(this,e,p)},()=>{n(!n())}],keydown:[function(p){he.call(this,e,p)},({key:p})=>{(p===" "||p==="Enter")&&n(!n())}],mouseover(p){he.call(this,e,p)},mouseenter(p){he.call(this,e,p)},mouseleave(p){he.call(this,e,p)}},children:(p,d)=>{var _=ze(),y=q(_);Ke(y,e,"default",{},null),v(p,_)},$$slots:{default:!0}})),Ie()}const Di=()=>[{lang:"de"},{lang:"en"},{lang:"fr"},{lang:"es"},{lang:"it"}],fh=Object.freeze(Object.defineProperty({__proto__:null,entries:Di},Symbol.toStringTag,{value:"Module"}));var Ni=ke("<title> </title>"),Li=ke('<svg><!><path d="M24 21H26V26H24zM20 16H22V26H20zM11 26a5.0059 5.0059 0 01-5-5H8a3 3 0 103-3V16a5 5 0 010 10z"></path><path d="M28,2H4A2.002,2.002,0,0,0,2,4V28a2.0023,2.0023,0,0,0,2,2H28a2.0027,2.0027,0,0,0,2-2V4A2.0023,2.0023,0,0,0,28,2Zm0,9H14V4H28ZM12,4v7H4V4ZM4,28V13H28.0007l.0013,15Z"></path></svg>');function Ui(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=Li();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=Ni(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var Hi=ke("<title> </title>"),Bi=ke('<svg><!><path d="M17.74,30,16,29l4-7h6a2,2,0,0,0,2-2V8a2,2,0,0,0-2-2H6A2,2,0,0,0,4,8V20a2,2,0,0,0,2,2h9v2H6a4,4,0,0,1-4-4V8A4,4,0,0,1,6,4H26a4,4,0,0,1,4,4V20a4,4,0,0,1-4,4H21.16Z"></path><path d="M8 10H24V12H8zM8 16H18V18H8z"></path></svg>');function Vi(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=Bi();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=Hi(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var zi=ke("<title> </title>"),Fi=ke('<svg><!><path d="M22,22v6H6V4H16V2H6A2,2,0,0,0,4,4V28a2,2,0,0,0,2,2H22a2,2,0,0,0,2-2V22Z"></path><path d="M29.54,5.76l-3.3-3.3a1.6,1.6,0,0,0-2.24,0l-14,14V22h5.53l14-14a1.6,1.6,0,0,0,0-2.24ZM14.7,20H12V17.3l9.44-9.45,2.71,2.71ZM25.56,9.15,22.85,6.44l2.27-2.27,2.71,2.71Z"></path></svg>');function Wi(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=Fi();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=zi(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var ji=ke("<title> </title>"),qi=ke('<svg><!><path d="M25.7,9.3l-7-7C18.5,2.1,18.3,2,18,2H8C6.9,2,6,2.9,6,4v24c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2V10C26,9.7,25.9,9.5,25.7,9.3	z M18,4.4l5.6,5.6H18V4.4z M24,28H8V4h8v6c0,1.1,0.9,2,2,2h6V28z"></path><path d="M10 22H22V24H10zM10 16H22V18H10z"></path></svg>');function Gi(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=qi();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=ji(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var Ki=ke("<title> </title>"),Yi=ke('<svg><!><path d="M4 16H16V18H4zM2 11H12V13H2z"></path><path d="M29.9189,16.6064l-3-7A.9985.9985,0,0,0,26,9H23V7a1,1,0,0,0-1-1H6V8H21V20.5562A3.9924,3.9924,0,0,0,19.1421,23H12.8579a4,4,0,1,0,0,2h6.2842a3.9806,3.9806,0,0,0,7.7158,0H29a1,1,0,0,0,1-1V17A.9965.9965,0,0,0,29.9189,16.6064ZM9,26a2,2,0,1,1,2-2A2.0023,2.0023,0,0,1,9,26ZM23,11h2.3408l2.1431,5H23Zm0,15a2,2,0,1,1,2-2A2.0023,2.0023,0,0,1,23,26Zm5-3H26.8579A3.9954,3.9954,0,0,0,23,20V18h5Z"></path></svg>');function zs(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=Yi();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=Ki(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var Ji=ke("<title> </title>"),Zi=ke('<svg><!><path d="M19 24H23V28H19zM26 24H30V28H26zM19 17H23V21H19zM26 17H30V21H26z"></path><path d="M17,24H4V10H28v5h2V10a2.0023,2.0023,0,0,0-2-2H22V4a2.0023,2.0023,0,0,0-2-2H12a2.002,2.002,0,0,0-2,2V8H4a2.002,2.002,0,0,0-2,2V24a2.0023,2.0023,0,0,0,2,2H17ZM12,4h8V8H12Z"></path></svg>');function Qi(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=Zi();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=Ji(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var Xi=ke("<title> </title>"),ea=ke('<svg><!><path d="M26,2H8A2,2,0,0,0,6,4V8H4v2H6v5H4v2H6v5H4v2H6v4a2,2,0,0,0,2,2H26a2,2,0,0,0,2-2V4A2,2,0,0,0,26,2Zm0,26H8V24h2V22H8V17h2V15H8V10h2V8H8V4H26Z"></path><path d="M14 8H22V10H14zM14 15H22V17H14zM14 22H22V24H14z"></path></svg>');function ta(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=ea();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=Xi(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var ra=ke("<title> </title>"),sa=ke('<svg><!><path d="M6,30H18a2.0023,2.0023,0,0,0,2-2V25H18v3H6V4H18V7h2V4a2.0023,2.0023,0,0,0-2-2H6A2.0023,2.0023,0,0,0,4,4V28A2.0023,2.0023,0,0,0,6,30Z"></path><path d="M20.586 20.586L24.172 17 10 17 10 15 24.172 15 20.586 11.414 22 10 28 16 22 22 20.586 20.586z"></path></svg>');function na(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=sa();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=ra(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(2),h(l),v(r,l),Ie()}var ia=T('<div class="nav-tile-content svelte-rkjaj2"><!> <span> </span></div>'),aa=T('<div class="nav-tile-content svelte-rkjaj2"><!> <span>Abmelden</span></div>'),oa=T('<div class="user-section svelte-rkjaj2"><div class="user-info svelte-rkjaj2"><span class="user-email svelte-rkjaj2"> </span></div> <!></div>'),la=T('<a class="logo-link svelte-rkjaj2"><img alt="statiqs logo" class="sidebar-logo svelte-rkjaj2"/></a> <div class="nav-section svelte-rkjaj2"><p class="nav-label svelte-rkjaj2">MY VIEW</p> <!></div> <!>',1),ca=T('<aside class="sidebar svelte-rkjaj2"><!></aside>');function da(r,e){we(e,!0);let t=E(e,"isOpen",11,!0),s=E(e,"activeItem",3,"orders"),n=E(e,"user",3,null);const i=Ds("lang")||"en";function a(p,d){var _;p.preventDefault(),(_=e.onNavigate)==null||_.call(e,d)}const o=[{id:"dashboard",text:"Dashboard",icon:Ui},{id:"chats",text:"Chats",icon:Vi},{id:"requests",text:"My Requests",icon:Wi},{id:"quotes",text:"My Quotes",icon:Gi},{id:"orders",text:"My Orders",icon:zs},{id:"products",text:"My Products",icon:Qi},{id:"catalogue",text:"Catalogue",icon:ta}];var l=ze(),u=q(l);{var m=p=>{var d=ca(),_=f(d);Le(_,{light:!0,class:"sidebar-tile",children:(y,C)=>{var I=la(),w=q(I),S=f(w);h(w);var M=g(w,2),O=g(f(M),2);kt(O,17,()=>o,Lt,(V,H)=>{const A=Ns(()=>s()===c(H).id?"active":"");Ft(V,{get class(){return`nav-tile ${c(A)??""}`},$$events:{click:k=>a(k,c(H).id)},children:(k,B)=>{var U=ia(),F=f(U);dr(F,()=>c(H).icon,(z,fe)=>{fe(z,{size:20})});var L=g(F,2),x=f(L,!0);h(L),h(U),R(()=>P(x,c(H).text)),v(k,U)},$$slots:{default:!0}})}),h(M);var b=g(M,2);{var j=V=>{var H=oa(),A=f(H),k=f(A),B=f(k,!0);h(k),h(A);var U=g(A,2);Ft(U,{class:"nav-tile logout-tile",$$events:{click(...F){var L;(L=e.onLogout)==null||L.apply(this,F)}},children:(F,L)=>{var x=aa(),z=f(x);na(z,{size:20}),W(2),h(x),v(F,x)},$$slots:{default:!0}}),h(H),R(()=>P(B,n().email)),v(V,H)};N(b,V=>{n()&&V(j)})}R(()=>{Ve(w,"href",`${es??""}/${i}`),Ve(S,"src",`${es??""}/corporate/Logo_breit.svg`)}),v(y,I)},$$slots:{default:!0}}),h(d),v(p,d)};N(u,p=>{t()&&p(m)})}v(r,l),Ie()}const ua=()=>{};var ss={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fs=function(r){const e=[];let t=0;for(let s=0;s<r.length;s++){let n=r.charCodeAt(s);n<128?e[t++]=n:n<2048?(e[t++]=n>>6|192,e[t++]=n&63|128):(n&64512)===55296&&s+1<r.length&&(r.charCodeAt(s+1)&64512)===56320?(n=65536+((n&1023)<<10)+(r.charCodeAt(++s)&1023),e[t++]=n>>18|240,e[t++]=n>>12&63|128,e[t++]=n>>6&63|128,e[t++]=n&63|128):(e[t++]=n>>12|224,e[t++]=n>>6&63|128,e[t++]=n&63|128)}return e},ha=function(r){const e=[];let t=0,s=0;for(;t<r.length;){const n=r[t++];if(n<128)e[s++]=String.fromCharCode(n);else if(n>191&&n<224){const i=r[t++];e[s++]=String.fromCharCode((n&31)<<6|i&63)}else if(n>239&&n<365){const i=r[t++],a=r[t++],o=r[t++],l=((n&7)<<18|(i&63)<<12|(a&63)<<6|o&63)-65536;e[s++]=String.fromCharCode(55296+(l>>10)),e[s++]=String.fromCharCode(56320+(l&1023))}else{const i=r[t++],a=r[t++];e[s++]=String.fromCharCode((n&15)<<12|(i&63)<<6|a&63)}}return e.join("")},Ws={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(r,e){if(!Array.isArray(r))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let n=0;n<r.length;n+=3){const i=r[n],a=n+1<r.length,o=a?r[n+1]:0,l=n+2<r.length,u=l?r[n+2]:0,m=i>>2,p=(i&3)<<4|o>>4;let d=(o&15)<<2|u>>6,_=u&63;l||(_=64,a||(d=64)),s.push(t[m],t[p],t[d],t[_])}return s.join("")},encodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(r):this.encodeByteArray(Fs(r),e)},decodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(r):ha(this.decodeStringToByteArray(r,e))},decodeStringToByteArray(r,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let n=0;n<r.length;){const i=t[r.charAt(n++)],o=n<r.length?t[r.charAt(n)]:0;++n;const u=n<r.length?t[r.charAt(n)]:64;++n;const p=n<r.length?t[r.charAt(n)]:64;if(++n,i==null||o==null||u==null||p==null)throw new fa;const d=i<<2|o>>4;if(s.push(d),u!==64){const _=o<<4&240|u>>2;if(s.push(_),p!==64){const y=u<<6&192|p;s.push(y)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let r=0;r<this.ENCODED_VALS.length;r++)this.byteToCharMap_[r]=this.ENCODED_VALS.charAt(r),this.charToByteMap_[this.byteToCharMap_[r]]=r,this.byteToCharMapWebSafe_[r]=this.ENCODED_VALS_WEBSAFE.charAt(r),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[r]]=r,r>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(r)]=r,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(r)]=r)}}};class fa extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const va=function(r){const e=Fs(r);return Ws.encodeByteArray(e,!0)},js=function(r){return va(r).replace(/\./g,"")},qs=function(r){try{return Ws.decodeString(r,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pa(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ga=()=>pa().__FIREBASE_DEFAULTS__,ma=()=>{if(typeof process>"u"||typeof ss>"u")return;const r=ss.__FIREBASE_DEFAULTS__;if(r)return JSON.parse(r)},_a=()=>{if(typeof document>"u")return;let r;try{r=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=r&&qs(r[1]);return e&&JSON.parse(e)},zr=()=>{try{return ua()||ga()||ma()||_a()}catch(r){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${r}`);return}},ba=r=>{var e,t;return(t=(e=zr())==null?void 0:e.emulatorHosts)==null?void 0:t[r]},Gs=()=>{var r;return(r=zr())==null?void 0:r.config},Ks=r=>{var e;return(e=zr())==null?void 0:e[`_${r}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ya{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function br(r){try{return(r.startsWith("http://")||r.startsWith("https://")?new URL(r).hostname:r).endsWith(".cloudworkstations.dev")}catch{return!1}}async function wa(r){return(await fetch(r,{credentials:"include"})).ok}const Wt={};function Ia(){const r={prod:[],emulator:[]};for(const e of Object.keys(Wt))Wt[e]?r.emulator.push(e):r.prod.push(e);return r}function Ea(r){let e=document.getElementById(r),t=!1;return e||(e=document.createElement("div"),e.setAttribute("id",r),t=!0),{created:t,element:e}}let ns=!1;function Ta(r,e){if(typeof window>"u"||typeof document>"u"||!br(window.location.host)||Wt[r]===e||Wt[r]||ns)return;Wt[r]=e;function t(d){return`__firebase__banner__${d}`}const s="__firebase__banner",i=Ia().prod.length>0;function a(){const d=document.getElementById(s);d&&d.remove()}function o(d){d.style.display="flex",d.style.background="#7faaf0",d.style.position="fixed",d.style.bottom="5px",d.style.left="5px",d.style.padding=".5em",d.style.borderRadius="5px",d.style.alignItems="center"}function l(d,_){d.setAttribute("width","24"),d.setAttribute("id",_),d.setAttribute("height","24"),d.setAttribute("viewBox","0 0 24 24"),d.setAttribute("fill","none"),d.style.marginLeft="-6px"}function u(){const d=document.createElement("span");return d.style.cursor="pointer",d.style.marginLeft="16px",d.style.fontSize="24px",d.innerHTML=" &times;",d.onclick=()=>{ns=!0,a()},d}function m(d,_){d.setAttribute("id",_),d.innerText="Learn more",d.href="https://firebase.google.com/docs/studio/preview-apps#preview-backend",d.setAttribute("target","__blank"),d.style.paddingLeft="5px",d.style.textDecoration="underline"}function p(){const d=Ea(s),_=t("text"),y=document.getElementById(_)||document.createElement("span"),C=t("learnmore"),I=document.getElementById(C)||document.createElement("a"),w=t("preprendIcon"),S=document.getElementById(w)||document.createElementNS("http://www.w3.org/2000/svg","svg");if(d.created){const M=d.element;o(M),m(I,C);const O=u();l(S,w),M.append(S,y,I,O),document.body.appendChild(M)}i?(y.innerText="Preview backend disconnected.",S.innerHTML=`<g clip-path="url(#clip0_6013_33858)">
<path d="M4.8 17.6L12 5.6L19.2 17.6H4.8ZM6.91667 16.4H17.0833L12 7.93333L6.91667 16.4ZM12 15.6C12.1667 15.6 12.3056 15.5444 12.4167 15.4333C12.5389 15.3111 12.6 15.1667 12.6 15C12.6 14.8333 12.5389 14.6944 12.4167 14.5833C12.3056 14.4611 12.1667 14.4 12 14.4C11.8333 14.4 11.6889 14.4611 11.5667 14.5833C11.4556 14.6944 11.4 14.8333 11.4 15C11.4 15.1667 11.4556 15.3111 11.5667 15.4333C11.6889 15.5444 11.8333 15.6 12 15.6ZM11.4 13.6H12.6V10.4H11.4V13.6Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6013_33858">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`):(S.innerHTML=`<g clip-path="url(#clip0_6083_34804)">
<path d="M11.4 15.2H12.6V11.2H11.4V15.2ZM12 10C12.1667 10 12.3056 9.94444 12.4167 9.83333C12.5389 9.71111 12.6 9.56667 12.6 9.4C12.6 9.23333 12.5389 9.09444 12.4167 8.98333C12.3056 8.86111 12.1667 8.8 12 8.8C11.8333 8.8 11.6889 8.86111 11.5667 8.98333C11.4556 9.09444 11.4 9.23333 11.4 9.4C11.4 9.56667 11.4556 9.71111 11.5667 9.83333C11.6889 9.94444 11.8333 10 12 10ZM12 18.4C11.1222 18.4 10.2944 18.2333 9.51667 17.9C8.73889 17.5667 8.05556 17.1111 7.46667 16.5333C6.88889 15.9444 6.43333 15.2611 6.1 14.4833C5.76667 13.7056 5.6 12.8778 5.6 12C5.6 11.1111 5.76667 10.2833 6.1 9.51667C6.43333 8.73889 6.88889 8.06111 7.46667 7.48333C8.05556 6.89444 8.73889 6.43333 9.51667 6.1C10.2944 5.76667 11.1222 5.6 12 5.6C12.8889 5.6 13.7167 5.76667 14.4833 6.1C15.2611 6.43333 15.9389 6.89444 16.5167 7.48333C17.1056 8.06111 17.5667 8.73889 17.9 9.51667C18.2333 10.2833 18.4 11.1111 18.4 12C18.4 12.8778 18.2333 13.7056 17.9 14.4833C17.5667 15.2611 17.1056 15.9444 16.5167 16.5333C15.9389 17.1111 15.2611 17.5667 14.4833 17.9C13.7167 18.2333 12.8889 18.4 12 18.4ZM12 17.2C13.4444 17.2 14.6722 16.6944 15.6833 15.6833C16.6944 14.6722 17.2 13.4444 17.2 12C17.2 10.5556 16.6944 9.32778 15.6833 8.31667C14.6722 7.30555 13.4444 6.8 12 6.8C10.5556 6.8 9.32778 7.30555 8.31667 8.31667C7.30556 9.32778 6.8 10.5556 6.8 12C6.8 13.4444 7.30556 14.6722 8.31667 15.6833C9.32778 16.6944 10.5556 17.2 12 17.2Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6083_34804">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`,y.innerText="Preview backend running in this workspace."),y.setAttribute("id",_)}document.readyState==="loading"?window.addEventListener("DOMContentLoaded",p):p()}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Be(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Pa(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Be())}function xa(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function ka(){const r=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof r=="object"&&r.id!==void 0}function Aa(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function Sa(){const r=Be();return r.indexOf("MSIE ")>=0||r.indexOf("Trident/")>=0}function Ca(){try{return typeof indexedDB=="object"}catch{return!1}}function $a(){return new Promise((r,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",n=self.indexedDB.open(s);n.onsuccess=()=>{n.result.close(),t||self.indexedDB.deleteDatabase(s),r(!0)},n.onupgradeneeded=()=>{t=!1},n.onerror=()=>{var i;e(((i=n.error)==null?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ra="FirebaseError";class wt extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=Ra,Object.setPrototypeOf(this,wt.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Qt.prototype.create)}}class Qt{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},n=`${this.service}/${e}`,i=this.errors[e],a=i?Oa(i,s):"Error",o=`${this.serviceName}: ${a} (${n}).`;return new wt(n,o,s)}}function Oa(r,e){return r.replace(Ma,(t,s)=>{const n=e[s];return n!=null?String(n):`<${s}?>`})}const Ma=/\{\$([^}]+)}/g;function Da(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}function Dt(r,e){if(r===e)return!0;const t=Object.keys(r),s=Object.keys(e);for(const n of t){if(!s.includes(n))return!1;const i=r[n],a=e[n];if(is(i)&&is(a)){if(!Dt(i,a))return!1}else if(i!==a)return!1}for(const n of s)if(!t.includes(n))return!1;return!0}function is(r){return r!==null&&typeof r=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xt(r){const e=[];for(const[t,s]of Object.entries(r))Array.isArray(s)?s.forEach(n=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(n))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}function Vt(r){const e={};return r.replace(/^\?/,"").split("&").forEach(s=>{if(s){const[n,i]=s.split("=");e[decodeURIComponent(n)]=decodeURIComponent(i)}}),e}function zt(r){const e=r.indexOf("?");if(!e)return"";const t=r.indexOf("#",e);return r.substring(e,t>0?t:void 0)}function Na(r,e){const t=new La(r,e);return t.subscribe.bind(t)}class La{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let n;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");Ua(e,["next","error","complete"])?n=e:n={next:e,error:t,complete:s},n.next===void 0&&(n.next=xr),n.error===void 0&&(n.error=xr),n.complete===void 0&&(n.complete=xr);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?n.error(this.finalError):n.complete()}catch{}}),this.observers.push(n),i}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function Ua(r,e){if(typeof r!="object"||r===null)return!1;for(const t of e)if(t in r&&typeof r[t]=="function")return!0;return!1}function xr(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ct(r){return r&&r._delegate?r._delegate:r}class Nt{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tt="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ha{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new ya;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const n=this.getOrInitializeService({instanceIdentifier:t});n&&s.resolve(n)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),s=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(n){if(s)return null;throw n}else{if(s)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Va(e))try{this.getOrInitializeService({instanceIdentifier:Tt})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const n=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:n});s.resolve(i)}catch{}}}}clearInstance(e=Tt){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Tt){return this.instances.has(e)}getOptions(e=Tt){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const n=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[i,a]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(i);s===o&&a.resolve(n)}return n}onInit(e,t){const s=this.normalizeInstanceIdentifier(t),n=this.onInitCallbacks.get(s)??new Set;n.add(e),this.onInitCallbacks.set(s,n);const i=this.instances.get(s);return i&&e(i,s),()=>{n.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const n of s)try{n(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:Ba(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=Tt){return this.component?this.component.multipleInstances?e:Tt:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Ba(r){return r===Tt?void 0:r}function Va(r){return r.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class za{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new Ha(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var be;(function(r){r[r.DEBUG=0]="DEBUG",r[r.VERBOSE=1]="VERBOSE",r[r.INFO=2]="INFO",r[r.WARN=3]="WARN",r[r.ERROR=4]="ERROR",r[r.SILENT=5]="SILENT"})(be||(be={}));const Fa={debug:be.DEBUG,verbose:be.VERBOSE,info:be.INFO,warn:be.WARN,error:be.ERROR,silent:be.SILENT},Wa=be.INFO,ja={[be.DEBUG]:"log",[be.VERBOSE]:"log",[be.INFO]:"info",[be.WARN]:"warn",[be.ERROR]:"error"},qa=(r,e,...t)=>{if(e<r.logLevel)return;const s=new Date().toISOString(),n=ja[e];if(n)console[n](`[${s}]  ${r.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Ys{constructor(e){this.name=e,this._logLevel=Wa,this._logHandler=qa,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in be))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Fa[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,be.DEBUG,...e),this._logHandler(this,be.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,be.VERBOSE,...e),this._logHandler(this,be.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,be.INFO,...e),this._logHandler(this,be.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,be.WARN,...e),this._logHandler(this,be.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,be.ERROR,...e),this._logHandler(this,be.ERROR,...e)}}const Ga=(r,e)=>e.some(t=>r instanceof t);let as,os;function Ka(){return as||(as=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Ya(){return os||(os=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Js=new WeakMap,Or=new WeakMap,Zs=new WeakMap,kr=new WeakMap,Fr=new WeakMap;function Ja(r){const e=new Promise((t,s)=>{const n=()=>{r.removeEventListener("success",i),r.removeEventListener("error",a)},i=()=>{t(_t(r.result)),n()},a=()=>{s(r.error),n()};r.addEventListener("success",i),r.addEventListener("error",a)});return e.then(t=>{t instanceof IDBCursor&&Js.set(t,r)}).catch(()=>{}),Fr.set(e,r),e}function Za(r){if(Or.has(r))return;const e=new Promise((t,s)=>{const n=()=>{r.removeEventListener("complete",i),r.removeEventListener("error",a),r.removeEventListener("abort",a)},i=()=>{t(),n()},a=()=>{s(r.error||new DOMException("AbortError","AbortError")),n()};r.addEventListener("complete",i),r.addEventListener("error",a),r.addEventListener("abort",a)});Or.set(r,e)}let Mr={get(r,e,t){if(r instanceof IDBTransaction){if(e==="done")return Or.get(r);if(e==="objectStoreNames")return r.objectStoreNames||Zs.get(r);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return _t(r[e])},set(r,e,t){return r[e]=t,!0},has(r,e){return r instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in r}};function Qa(r){Mr=r(Mr)}function Xa(r){return r===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=r.call(Ar(this),e,...t);return Zs.set(s,e.sort?e.sort():[e]),_t(s)}:Ya().includes(r)?function(...e){return r.apply(Ar(this),e),_t(Js.get(this))}:function(...e){return _t(r.apply(Ar(this),e))}}function eo(r){return typeof r=="function"?Xa(r):(r instanceof IDBTransaction&&Za(r),Ga(r,Ka())?new Proxy(r,Mr):r)}function _t(r){if(r instanceof IDBRequest)return Ja(r);if(kr.has(r))return kr.get(r);const e=eo(r);return e!==r&&(kr.set(r,e),Fr.set(e,r)),e}const Ar=r=>Fr.get(r);function to(r,e,{blocked:t,upgrade:s,blocking:n,terminated:i}={}){const a=indexedDB.open(r,e),o=_t(a);return s&&a.addEventListener("upgradeneeded",l=>{s(_t(a.result),l.oldVersion,l.newVersion,_t(a.transaction),l)}),t&&a.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),o.then(l=>{i&&l.addEventListener("close",()=>i()),n&&l.addEventListener("versionchange",u=>n(u.oldVersion,u.newVersion,u))}).catch(()=>{}),o}const ro=["get","getKey","getAll","getAllKeys","count"],so=["put","add","delete","clear"],Sr=new Map;function ls(r,e){if(!(r instanceof IDBDatabase&&!(e in r)&&typeof e=="string"))return;if(Sr.get(e))return Sr.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,n=so.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(n||ro.includes(t)))return;const i=async function(a,...o){const l=this.transaction(a,n?"readwrite":"readonly");let u=l.store;return s&&(u=u.index(o.shift())),(await Promise.all([u[t](...o),n&&l.done]))[0]};return Sr.set(e,i),i}Qa(r=>({...r,get:(e,t,s)=>ls(e,t)||r.get(e,t,s),has:(e,t)=>!!ls(e,t)||r.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class no{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(io(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function io(r){const e=r.getComponent();return(e==null?void 0:e.type)==="VERSION"}const Dr="@firebase/app",cs="0.14.8";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ot=new Ys("@firebase/app"),ao="@firebase/app-compat",oo="@firebase/analytics-compat",lo="@firebase/analytics",co="@firebase/app-check-compat",uo="@firebase/app-check",ho="@firebase/auth",fo="@firebase/auth-compat",vo="@firebase/database",po="@firebase/data-connect",go="@firebase/database-compat",mo="@firebase/functions",_o="@firebase/functions-compat",bo="@firebase/installations",yo="@firebase/installations-compat",wo="@firebase/messaging",Io="@firebase/messaging-compat",Eo="@firebase/performance",To="@firebase/performance-compat",Po="@firebase/remote-config",xo="@firebase/remote-config-compat",ko="@firebase/storage",Ao="@firebase/storage-compat",So="@firebase/firestore",Co="@firebase/ai",$o="@firebase/firestore-compat",Ro="firebase",Oo="12.9.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nr="[DEFAULT]",Mo={[Dr]:"fire-core",[ao]:"fire-core-compat",[lo]:"fire-analytics",[oo]:"fire-analytics-compat",[uo]:"fire-app-check",[co]:"fire-app-check-compat",[ho]:"fire-auth",[fo]:"fire-auth-compat",[vo]:"fire-rtdb",[po]:"fire-data-connect",[go]:"fire-rtdb-compat",[mo]:"fire-fn",[_o]:"fire-fn-compat",[bo]:"fire-iid",[yo]:"fire-iid-compat",[wo]:"fire-fcm",[Io]:"fire-fcm-compat",[Eo]:"fire-perf",[To]:"fire-perf-compat",[Po]:"fire-rc",[xo]:"fire-rc-compat",[ko]:"fire-gcs",[Ao]:"fire-gcs-compat",[So]:"fire-fst",[$o]:"fire-fst-compat",[Co]:"fire-vertex","fire-js":"fire-js",[Ro]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ur=new Map,Do=new Map,Lr=new Map;function ds(r,e){try{r.container.addComponent(e)}catch(t){ot.debug(`Component ${e.name} failed to register with FirebaseApp ${r.name}`,t)}}function Gt(r){const e=r.name;if(Lr.has(e))return ot.debug(`There were multiple attempts to register component ${e}.`),!1;Lr.set(e,r);for(const t of ur.values())ds(t,r);for(const t of Do.values())ds(t,r);return!0}function Qs(r,e){const t=r.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),r.container.getProvider(e)}function Ge(r){return r==null?!1:r.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const No={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},bt=new Qt("app","Firebase",No);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lo{constructor(e,t,s){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new Nt("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw bt.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const er=Oo;function Xs(r,e={}){let t=r;typeof e!="object"&&(e={name:e});const s={name:Nr,automaticDataCollectionEnabled:!0,...e},n=s.name;if(typeof n!="string"||!n)throw bt.create("bad-app-name",{appName:String(n)});if(t||(t=Gs()),!t)throw bt.create("no-options");const i=ur.get(n);if(i){if(Dt(t,i.options)&&Dt(s,i.config))return i;throw bt.create("duplicate-app",{appName:n})}const a=new za(n);for(const l of Lr.values())a.addComponent(l);const o=new Lo(t,s,a);return ur.set(n,o),o}function Uo(r=Nr){const e=ur.get(r);if(!e&&r===Nr&&Gs())return Xs();if(!e)throw bt.create("no-app",{appName:r});return e}function Ct(r,e,t){let s=Mo[r]??r;t&&(s+=`-${t}`);const n=s.match(/\s|\//),i=e.match(/\s|\//);if(n||i){const a=[`Unable to register library "${s}" with version "${e}":`];n&&a.push(`library name "${s}" contains illegal characters (whitespace or "/")`),n&&i&&a.push("and"),i&&a.push(`version name "${e}" contains illegal characters (whitespace or "/")`),ot.warn(a.join(" "));return}Gt(new Nt(`${s}-version`,()=>({library:s,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ho="firebase-heartbeat-database",Bo=1,Kt="firebase-heartbeat-store";let Cr=null;function en(){return Cr||(Cr=to(Ho,Bo,{upgrade:(r,e)=>{switch(e){case 0:try{r.createObjectStore(Kt)}catch(t){console.warn(t)}}}}).catch(r=>{throw bt.create("idb-open",{originalErrorMessage:r.message})})),Cr}async function Vo(r){try{const t=(await en()).transaction(Kt),s=await t.objectStore(Kt).get(tn(r));return await t.done,s}catch(e){if(e instanceof wt)ot.warn(e.message);else{const t=bt.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});ot.warn(t.message)}}}async function us(r,e){try{const s=(await en()).transaction(Kt,"readwrite");await s.objectStore(Kt).put(e,tn(r)),await s.done}catch(t){if(t instanceof wt)ot.warn(t.message);else{const s=bt.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});ot.warn(s.message)}}}function tn(r){return`${r.name}!${r.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zo=1024,Fo=30;class Wo{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new qo(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;try{const n=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=hs();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(a=>a.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:n}),this._heartbeatsCache.heartbeats.length>Fo){const a=Go(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(a,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(s){ot.warn(s)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=hs(),{heartbeatsToSend:s,unsentEntries:n}=jo(this._heartbeatsCache.heartbeats),i=js(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,n.length>0?(this._heartbeatsCache.heartbeats=n,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(t){return ot.warn(t),""}}}function hs(){return new Date().toISOString().substring(0,10)}function jo(r,e=zo){const t=[];let s=r.slice();for(const n of r){const i=t.find(a=>a.agent===n.agent);if(i){if(i.dates.push(n.date),fs(t)>e){i.dates.pop();break}}else if(t.push({agent:n.agent,dates:[n.date]}),fs(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class qo{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Ca()?$a().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await Vo(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return us(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return us(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:[...s.heartbeats,...e.heartbeats]})}else return}}function fs(r){return js(JSON.stringify({version:2,heartbeats:r})).length}function Go(r){if(r.length===0)return-1;let e=0,t=r[0].date;for(let s=1;s<r.length;s++)r[s].date<t&&(t=r[s].date,e=s);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ko(r){Gt(new Nt("platform-logger",e=>new no(e),"PRIVATE")),Gt(new Nt("heartbeat",e=>new Wo(e),"PRIVATE")),Ct(Dr,cs,r),Ct(Dr,cs,"esm2020"),Ct("fire-js","")}Ko("");var Yo="firebase",Jo="12.9.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ct(Yo,Jo,"app");function rn(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Zo=rn,sn=new Qt("auth","Firebase",rn());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hr=new Ys("@firebase/auth");function Qo(r,...e){hr.logLevel<=be.WARN&&hr.warn(`Auth (${er}): ${r}`,...e)}function ar(r,...e){hr.logLevel<=be.ERROR&&hr.error(`Auth (${er}): ${r}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Je(r,...e){throw Wr(r,...e)}function Xe(r,...e){return Wr(r,...e)}function nn(r,e,t){const s={...Zo(),[e]:t};return new Qt("auth","Firebase",s).create(e,{appName:r.name})}function at(r){return nn(r,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Wr(r,...e){if(typeof r!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=r.name),r._errorFactory.create(t,...s)}return sn.create(r,...e)}function G(r,e,...t){if(!r)throw Wr(e,...t)}function nt(r){const e="INTERNAL ASSERTION FAILED: "+r;throw ar(e),new Error(e)}function lt(r,e){r||nt(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ur(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.href)||""}function Xo(){return vs()==="http:"||vs()==="https:"}function vs(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function el(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Xo()||ka()||"connection"in navigator)?navigator.onLine:!0}function tl(){if(typeof navigator>"u")return null;const r=navigator;return r.languages&&r.languages[0]||r.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tr{constructor(e,t){this.shortDelay=e,this.longDelay=t,lt(t>e,"Short delay should be less than long delay!"),this.isMobile=Pa()||Aa()}get(){return el()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jr(r,e){lt(r.emulator,"Emulator should always be set here");const{url:t}=r.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class an{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;nt("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;nt("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;nt("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rl={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sl=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],nl=new tr(3e4,6e4);function dt(r,e){return r.tenantId&&!e.tenantId?{...e,tenantId:r.tenantId}:e}async function ut(r,e,t,s,n={}){return on(r,n,async()=>{let i={},a={};s&&(e==="GET"?a=s:i={body:JSON.stringify(s)});const o=Xt({key:r.config.apiKey,...a}).slice(1),l=await r._getAdditionalHeaders();l["Content-Type"]="application/json",r.languageCode&&(l["X-Firebase-Locale"]=r.languageCode);const u={method:e,headers:l,...i};return xa()||(u.referrerPolicy="no-referrer"),r.emulatorConfig&&br(r.emulatorConfig.host)&&(u.credentials="include"),an.fetch()(await ln(r,r.config.apiHost,t,o),u)})}async function on(r,e,t){r._canInitEmulator=!1;const s={...rl,...e};try{const n=new al(r),i=await Promise.race([t(),n.promise]);n.clearNetworkTimeout();const a=await i.json();if("needConfirmation"in a)throw ir(r,"account-exists-with-different-credential",a);if(i.ok&&!("errorMessage"in a))return a;{const o=i.ok?a.errorMessage:a.error.message,[l,u]=o.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw ir(r,"credential-already-in-use",a);if(l==="EMAIL_EXISTS")throw ir(r,"email-already-in-use",a);if(l==="USER_DISABLED")throw ir(r,"user-disabled",a);const m=s[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw nn(r,m,u);Je(r,m)}}catch(n){if(n instanceof wt)throw n;Je(r,"network-request-failed",{message:String(n)})}}async function rr(r,e,t,s,n={}){const i=await ut(r,e,t,s,n);return"mfaPendingCredential"in i&&Je(r,"multi-factor-auth-required",{_serverResponse:i}),i}async function ln(r,e,t,s){const n=`${e}${t}?${s}`,i=r,a=i.config.emulator?jr(r.config,n):`${r.config.apiScheme}://${n}`;return sl.includes(t)&&(await i._persistenceManagerAvailable,i._getPersistenceType()==="COOKIE")?i._getPersistence()._getFinalTarget(a).toString():a}function il(r){switch(r){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class al{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(Xe(this.auth,"network-request-failed")),nl.get())})}}function ir(r,e,t){const s={appName:r.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const n=Xe(r,e,s);return n.customData._tokenResponse=t,n}function ps(r){return r!==void 0&&r.enterprise!==void 0}class ol{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return il(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}async function ll(r,e){return ut(r,"GET","/v2/recaptchaConfig",dt(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function cl(r,e){return ut(r,"POST","/v1/accounts:delete",e)}async function fr(r,e){return ut(r,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jt(r){if(r)try{const e=new Date(Number(r));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function dl(r,e=!1){const t=ct(r),s=await t.getIdToken(e),n=qr(s);G(n&&n.exp&&n.auth_time&&n.iat,t.auth,"internal-error");const i=typeof n.firebase=="object"?n.firebase:void 0,a=i==null?void 0:i.sign_in_provider;return{claims:n,token:s,authTime:jt($r(n.auth_time)),issuedAtTime:jt($r(n.iat)),expirationTime:jt($r(n.exp)),signInProvider:a||null,signInSecondFactor:(i==null?void 0:i.sign_in_second_factor)||null}}function $r(r){return Number(r)*1e3}function qr(r){const[e,t,s]=r.split(".");if(e===void 0||t===void 0||s===void 0)return ar("JWT malformed, contained fewer than 3 sections"),null;try{const n=qs(t);return n?JSON.parse(n):(ar("Failed to decode base64 JWT payload"),null)}catch(n){return ar("Caught error parsing JWT payload as JSON",n==null?void 0:n.toString()),null}}function gs(r){const e=qr(r);return G(e,"internal-error"),G(typeof e.exp<"u","internal-error"),G(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Yt(r,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof wt&&ul(s)&&r.auth.currentUser===r&&await r.auth.signOut(),s}}function ul({code:r}){return r==="auth/user-disabled"||r==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hl{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const s=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,s)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hr{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=jt(this.lastLoginAt),this.creationTime=jt(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function vr(r){var p;const e=r.auth,t=await r.getIdToken(),s=await Yt(r,fr(e,{idToken:t}));G(s==null?void 0:s.users.length,e,"internal-error");const n=s.users[0];r._notifyReloadListener(n);const i=(p=n.providerUserInfo)!=null&&p.length?cn(n.providerUserInfo):[],a=vl(r.providerData,i),o=r.isAnonymous,l=!(r.email&&n.passwordHash)&&!(a!=null&&a.length),u=o?l:!1,m={uid:n.localId,displayName:n.displayName||null,photoURL:n.photoUrl||null,email:n.email||null,emailVerified:n.emailVerified||!1,phoneNumber:n.phoneNumber||null,tenantId:n.tenantId||null,providerData:a,metadata:new Hr(n.createdAt,n.lastLoginAt),isAnonymous:u};Object.assign(r,m)}async function fl(r){const e=ct(r);await vr(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function vl(r,e){return[...r.filter(s=>!e.some(n=>n.providerId===s.providerId)),...e]}function cn(r){return r.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function pl(r,e){const t=await on(r,{},async()=>{const s=Xt({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:n,apiKey:i}=r.config,a=await ln(r,n,"/v1/token",`key=${i}`),o=await r._getAdditionalHeaders();o["Content-Type"]="application/x-www-form-urlencoded";const l={method:"POST",headers:o,body:s};return r.emulatorConfig&&br(r.emulatorConfig.host)&&(l.credentials="include"),an.fetch()(a,l)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function gl(r,e){return ut(r,"POST","/v2/accounts:revokeToken",dt(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $t{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){G(e.idToken,"internal-error"),G(typeof e.idToken<"u","internal-error"),G(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):gs(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){G(e.length!==0,"internal-error");const t=gs(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(G(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:n,expiresIn:i}=await pl(e,t);this.updateTokensAndExpiration(s,n,Number(i))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:n,expirationTime:i}=t,a=new $t;return s&&(G(typeof s=="string","internal-error",{appName:e}),a.refreshToken=s),n&&(G(typeof n=="string","internal-error",{appName:e}),a.accessToken=n),i&&(G(typeof i=="number","internal-error",{appName:e}),a.expirationTime=i),a}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new $t,this.toJSON())}_performRefresh(){return nt("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ft(r,e){G(typeof r=="string"||typeof r>"u","internal-error",{appName:e})}class Ye{constructor({uid:e,auth:t,stsTokenManager:s,...n}){this.providerId="firebase",this.proactiveRefresh=new hl(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=s,this.accessToken=s.accessToken,this.displayName=n.displayName||null,this.email=n.email||null,this.emailVerified=n.emailVerified||!1,this.phoneNumber=n.phoneNumber||null,this.photoURL=n.photoURL||null,this.isAnonymous=n.isAnonymous||!1,this.tenantId=n.tenantId||null,this.providerData=n.providerData?[...n.providerData]:[],this.metadata=new Hr(n.createdAt||void 0,n.lastLoginAt||void 0)}async getIdToken(e){const t=await Yt(this,this.stsTokenManager.getToken(this.auth,e));return G(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return dl(this,e)}reload(){return fl(this)}_assign(e){this!==e&&(G(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new Ye({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){G(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await vr(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Ge(this.auth.app))return Promise.reject(at(this.auth));const e=await this.getIdToken();return await Yt(this,cl(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const s=t.displayName??void 0,n=t.email??void 0,i=t.phoneNumber??void 0,a=t.photoURL??void 0,o=t.tenantId??void 0,l=t._redirectEventId??void 0,u=t.createdAt??void 0,m=t.lastLoginAt??void 0,{uid:p,emailVerified:d,isAnonymous:_,providerData:y,stsTokenManager:C}=t;G(p&&C,e,"internal-error");const I=$t.fromJSON(this.name,C);G(typeof p=="string",e,"internal-error"),ft(s,e.name),ft(n,e.name),G(typeof d=="boolean",e,"internal-error"),G(typeof _=="boolean",e,"internal-error"),ft(i,e.name),ft(a,e.name),ft(o,e.name),ft(l,e.name),ft(u,e.name),ft(m,e.name);const w=new Ye({uid:p,auth:e,email:n,emailVerified:d,displayName:s,isAnonymous:_,photoURL:a,phoneNumber:i,tenantId:o,stsTokenManager:I,createdAt:u,lastLoginAt:m});return y&&Array.isArray(y)&&(w.providerData=y.map(S=>({...S}))),l&&(w._redirectEventId=l),w}static async _fromIdTokenResponse(e,t,s=!1){const n=new $t;n.updateFromServerResponse(t);const i=new Ye({uid:t.localId,auth:e,stsTokenManager:n,isAnonymous:s});return await vr(i),i}static async _fromGetAccountInfoResponse(e,t,s){const n=t.users[0];G(n.localId!==void 0,"internal-error");const i=n.providerUserInfo!==void 0?cn(n.providerUserInfo):[],a=!(n.email&&n.passwordHash)&&!(i!=null&&i.length),o=new $t;o.updateFromIdToken(s);const l=new Ye({uid:n.localId,auth:e,stsTokenManager:o,isAnonymous:a}),u={uid:n.localId,displayName:n.displayName||null,photoURL:n.photoUrl||null,email:n.email||null,emailVerified:n.emailVerified||!1,phoneNumber:n.phoneNumber||null,tenantId:n.tenantId||null,providerData:i,metadata:new Hr(n.createdAt,n.lastLoginAt),isAnonymous:!(n.email&&n.passwordHash)&&!(i!=null&&i.length)};return Object.assign(l,u),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ms=new Map;function it(r){lt(r instanceof Function,"Expected a class definition");let e=ms.get(r);return e?(lt(e instanceof r,"Instance stored in cache mismatched with class"),e):(e=new r,ms.set(r,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dn{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}dn.type="NONE";const _s=dn;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function or(r,e,t){return`firebase:${r}:${e}:${t}`}class Rt{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:n,name:i}=this.auth;this.fullUserKey=or(this.userKey,n.apiKey,i),this.fullPersistenceKey=or("persistence",n.apiKey,i),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await fr(this.auth,{idToken:e}).catch(()=>{});return t?Ye._fromGetAccountInfoResponse(this.auth,t,e):null}return Ye._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new Rt(it(_s),e,s);const n=(await Promise.all(t.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let i=n[0]||it(_s);const a=or(s,e.config.apiKey,e.name);let o=null;for(const u of t)try{const m=await u._get(a);if(m){let p;if(typeof m=="string"){const d=await fr(e,{idToken:m}).catch(()=>{});if(!d)break;p=await Ye._fromGetAccountInfoResponse(e,d,m)}else p=Ye._fromJSON(e,m);u!==i&&(o=p),i=u;break}}catch{}const l=n.filter(u=>u._shouldAllowMigration);return!i._shouldAllowMigration||!l.length?new Rt(i,e,s):(i=l[0],o&&await i._set(a,o.toJSON()),await Promise.all(t.map(async u=>{if(u!==i)try{await u._remove(a)}catch{}})),new Rt(i,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bs(r){const e=r.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(vn(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(un(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(gn(e))return"Blackberry";if(mn(e))return"Webos";if(hn(e))return"Safari";if((e.includes("chrome/")||fn(e))&&!e.includes("edge/"))return"Chrome";if(pn(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=r.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function un(r=Be()){return/firefox\//i.test(r)}function hn(r=Be()){const e=r.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function fn(r=Be()){return/crios\//i.test(r)}function vn(r=Be()){return/iemobile/i.test(r)}function pn(r=Be()){return/android/i.test(r)}function gn(r=Be()){return/blackberry/i.test(r)}function mn(r=Be()){return/webos/i.test(r)}function Gr(r=Be()){return/iphone|ipad|ipod/i.test(r)||/macintosh/i.test(r)&&/mobile/i.test(r)}function ml(r=Be()){var e;return Gr(r)&&!!((e=window.navigator)!=null&&e.standalone)}function _l(){return Sa()&&document.documentMode===10}function _n(r=Be()){return Gr(r)||pn(r)||mn(r)||gn(r)||/windows phone/i.test(r)||vn(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bn(r,e=[]){let t;switch(r){case"Browser":t=bs(Be());break;case"Worker":t=`${bs(Be())}-${r}`;break;default:t=r}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${er}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bl{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=i=>new Promise((a,o)=>{try{const l=e(i);a(l)}catch(l){o(l)}});s.onAbort=t,this.queue.push(s);const n=this.queue.length-1;return()=>{this.queue[n]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const n of t)try{n()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yl(r,e={}){return ut(r,"GET","/v2/passwordPolicy",dt(r,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wl=6;class Il{constructor(e){var s;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??wl,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((s=e.allowedNonAlphanumericCharacters)==null?void 0:s.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,n=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),n&&(t.meetsMaxPasswordLength=e.length<=n)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let n=0;n<e.length;n++)s=e.charAt(n),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,n,i){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=n)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class El{constructor(e,t,s,n){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=n,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new ys(this),this.idTokenSubscription=new ys(this),this.beforeStateQueue=new bl(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=sn,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=n.sdkClientVersion,this._persistenceManagerAvailable=new Promise(i=>this._resolvePersistenceManagerAvailable=i)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=it(t)),this._initializationPromise=this.queue(async()=>{var s,n,i;if(!this._deleted&&(this.persistenceManager=await Rt.create(this,e),(s=this._resolvePersistenceManagerAvailable)==null||s.call(this),!this._deleted)){if((n=this._popupRedirectResolver)!=null&&n._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((i=this.currentUser)==null?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await fr(this,{idToken:e}),s=await Ye._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var i;if(Ge(this.app)){const a=this.app.settings.authIdToken;return a?new Promise(o=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(a).then(o,o))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let s=t,n=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const a=(i=this.redirectUser)==null?void 0:i._redirectEventId,o=s==null?void 0:s._redirectEventId,l=await this.tryRedirectSignIn(e);(!a||a===o)&&(l!=null&&l.user)&&(s=l.user,n=!0)}if(!s)return this.directlySetCurrentUser(null);if(!s._redirectEventId){if(n)try{await this.beforeStateQueue.runMiddleware(s)}catch(a){s=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(a))}return s?this.reloadAndSetCurrentUserOrClear(s):this.directlySetCurrentUser(null)}return G(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===s._redirectEventId?this.directlySetCurrentUser(s):this.reloadAndSetCurrentUserOrClear(s)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await vr(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=tl()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Ge(this.app))return Promise.reject(at(this));const t=e?ct(e):null;return t&&G(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&G(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Ge(this.app)?Promise.reject(at(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Ge(this.app)?Promise.reject(at(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(it(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await yl(this),t=new Il(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Qt("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await gl(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&it(e)||this._popupRedirectResolver;G(t,this,"argument-error"),this.redirectPersistenceManager=await Rt.create(this,[it(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)==null?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,n){if(this._deleted)return()=>{};const i=typeof t=="function"?t:t.next.bind(t);let a=!1;const o=this._isInitialized?Promise.resolve():this._initializationPromise;if(G(o,this,"internal-error"),o.then(()=>{a||i(this.currentUser)}),typeof t=="function"){const l=e.addObserver(t,s,n);return()=>{a=!0,l()}}else{const l=e.addObserver(t);return()=>{a=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return G(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=bn(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var n;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((n=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:n.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const s=await this._getAppCheckToken();return s&&(e["X-Firebase-AppCheck"]=s),e}async _getAppCheckToken(){var t;if(Ge(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&Qo(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function It(r){return ct(r)}class ys{constructor(e){this.auth=e,this.observer=null,this.addObserver=Na(t=>this.observer=t)}get next(){return G(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let yr={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function Tl(r){yr=r}function yn(r){return yr.loadJS(r)}function Pl(){return yr.recaptchaEnterpriseScript}function xl(){return yr.gapiScript}function kl(r){return`__${r}${Math.floor(Math.random()*1e6)}`}class Al{constructor(){this.enterprise=new Sl}ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}class Sl{ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}const Cl="recaptcha-enterprise",wn="NO_RECAPTCHA";class $l{constructor(e){this.type=Cl,this.auth=It(e)}async verify(e="verify",t=!1){async function s(i){if(!t){if(i.tenantId==null&&i._agentRecaptchaConfig!=null)return i._agentRecaptchaConfig.siteKey;if(i.tenantId!=null&&i._tenantRecaptchaConfigs[i.tenantId]!==void 0)return i._tenantRecaptchaConfigs[i.tenantId].siteKey}return new Promise(async(a,o)=>{ll(i,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)o(new Error("recaptcha Enterprise site key undefined"));else{const u=new ol(l);return i.tenantId==null?i._agentRecaptchaConfig=u:i._tenantRecaptchaConfigs[i.tenantId]=u,a(u.siteKey)}}).catch(l=>{o(l)})})}function n(i,a,o){const l=window.grecaptcha;ps(l)?l.enterprise.ready(()=>{l.enterprise.execute(i,{action:e}).then(u=>{a(u)}).catch(()=>{a(wn)})}):o(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new Al().execute("siteKey",{action:"verify"}):new Promise((i,a)=>{s(this.auth).then(o=>{if(!t&&ps(window.grecaptcha))n(o,i,a);else{if(typeof window>"u"){a(new Error("RecaptchaVerifier is only supported in browser"));return}let l=Pl();l.length!==0&&(l+=o),yn(l).then(()=>{n(o,i,a)}).catch(u=>{a(u)})}}).catch(o=>{a(o)})})}}async function ws(r,e,t,s=!1,n=!1){const i=new $l(r);let a;if(n)a=wn;else try{a=await i.verify(t)}catch{a=await i.verify(t,!0)}const o={...e};if(t==="mfaSmsEnrollment"||t==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in o){const l=o.phoneEnrollmentInfo.phoneNumber,u=o.phoneEnrollmentInfo.recaptchaToken;Object.assign(o,{phoneEnrollmentInfo:{phoneNumber:l,recaptchaToken:u,captchaResponse:a,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in o){const l=o.phoneSignInInfo.recaptchaToken;Object.assign(o,{phoneSignInInfo:{recaptchaToken:l,captchaResponse:a,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return o}return s?Object.assign(o,{captchaResp:a}):Object.assign(o,{captchaResponse:a}),Object.assign(o,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(o,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),o}async function pr(r,e,t,s,n){var i;if((i=r._getRecaptchaConfig())!=null&&i.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const a=await ws(r,e,t,t==="getOobCode");return s(r,a)}else return s(r,e).catch(async a=>{if(a.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const o=await ws(r,e,t,t==="getOobCode");return s(r,o)}else return Promise.reject(a)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rl(r,e){const t=Qs(r,"auth");if(t.isInitialized()){const n=t.getImmediate(),i=t.getOptions();if(Dt(i,e??{}))return n;Je(n,"already-initialized")}return t.initialize({options:e})}function Ol(r,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(it);e!=null&&e.errorMap&&r._updateErrorMap(e.errorMap),r._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}function Ml(r,e,t){const s=It(r);G(/^https?:\/\//.test(e),s,"invalid-emulator-scheme");const n=!1,i=In(e),{host:a,port:o}=Dl(e),l=o===null?"":`:${o}`,u={url:`${i}//${a}${l}/`},m=Object.freeze({host:a,port:o,protocol:i.replace(":",""),options:Object.freeze({disableWarnings:n})});if(!s._canInitEmulator){G(s.config.emulator&&s.emulatorConfig,s,"emulator-config-failed"),G(Dt(u,s.config.emulator)&&Dt(m,s.emulatorConfig),s,"emulator-config-failed");return}s.config.emulator=u,s.emulatorConfig=m,s.settings.appVerificationDisabledForTesting=!0,br(a)?(wa(`${i}//${a}${l}`),Ta("Auth",!0)):Nl()}function In(r){const e=r.indexOf(":");return e<0?"":r.substr(0,e+1)}function Dl(r){const e=In(r),t=/(\/\/)?([^?#/]+)/.exec(r.substr(e.length));if(!t)return{host:"",port:null};const s=t[2].split("@").pop()||"",n=/^(\[[^\]]+\])(:|$)/.exec(s);if(n){const i=n[1];return{host:i,port:Is(s.substr(i.length+1))}}else{const[i,a]=s.split(":");return{host:i,port:Is(a)}}}function Is(r){if(!r)return null;const e=Number(r);return isNaN(e)?null:e}function Nl(){function r(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",r):r())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kr{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return nt("not implemented")}_getIdTokenResponse(e){return nt("not implemented")}_linkToIdToken(e,t){return nt("not implemented")}_getReauthenticationResolver(e){return nt("not implemented")}}async function Ll(r,e){return ut(r,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ul(r,e){return rr(r,"POST","/v1/accounts:signInWithPassword",dt(r,e))}async function Hl(r,e){return ut(r,"POST","/v1/accounts:sendOobCode",dt(r,e))}async function Bl(r,e){return Hl(r,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Vl(r,e){return rr(r,"POST","/v1/accounts:signInWithEmailLink",dt(r,e))}async function zl(r,e){return rr(r,"POST","/v1/accounts:signInWithEmailLink",dt(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jt extends Kr{constructor(e,t,s,n=null){super("password",s),this._email=e,this._password=t,this._tenantId=n}static _fromEmailAndPassword(e,t){return new Jt(e,t,"password")}static _fromEmailAndCode(e,t,s=null){return new Jt(e,t,"emailLink",s)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return pr(e,t,"signInWithPassword",Ul);case"emailLink":return Vl(e,{email:this._email,oobCode:this._password});default:Je(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const s={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return pr(e,s,"signUpPassword",Ll);case"emailLink":return zl(e,{idToken:t,email:this._email,oobCode:this._password});default:Je(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ot(r,e){return rr(r,"POST","/v1/accounts:signInWithIdp",dt(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fl="http://localhost";class Pt extends Kr{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Pt(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):Je("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:s,signInMethod:n,...i}=t;if(!s||!n)return null;const a=new Pt(s,n);return a.idToken=i.idToken||void 0,a.accessToken=i.accessToken||void 0,a.secret=i.secret,a.nonce=i.nonce,a.pendingToken=i.pendingToken||null,a}_getIdTokenResponse(e){const t=this.buildRequest();return Ot(e,t)}_linkToIdToken(e,t){const s=this.buildRequest();return s.idToken=t,Ot(e,s)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,Ot(e,t)}buildRequest(){const e={requestUri:Fl,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=Xt(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wl(r){switch(r){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function jl(r){const e=Vt(zt(r)).link,t=e?Vt(zt(e)).deep_link_id:null,s=Vt(zt(r)).deep_link_id;return(s?Vt(zt(s)).link:null)||s||t||e||r}class Yr{constructor(e){const t=Vt(zt(e)),s=t.apiKey??null,n=t.oobCode??null,i=Wl(t.mode??null);G(s&&n&&i,"argument-error"),this.apiKey=s,this.operation=i,this.code=n,this.continueUrl=t.continueUrl??null,this.languageCode=t.lang??null,this.tenantId=t.tenantId??null}static parseLink(e){const t=jl(e);try{return new Yr(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ut{constructor(){this.providerId=Ut.PROVIDER_ID}static credential(e,t){return Jt._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const s=Yr.parseLink(t);return G(s,"argument-error"),Jt._fromEmailAndCode(e,s.code,s.tenantId)}}Ut.PROVIDER_ID="password";Ut.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Ut.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class En{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sr extends En{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt extends sr{constructor(){super("facebook.com")}static credential(e){return Pt._fromParams({providerId:vt.PROVIDER_ID,signInMethod:vt.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return vt.credentialFromTaggedObject(e)}static credentialFromError(e){return vt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return vt.credential(e.oauthAccessToken)}catch{return null}}}vt.FACEBOOK_SIGN_IN_METHOD="facebook.com";vt.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pt extends sr{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Pt._fromParams({providerId:pt.PROVIDER_ID,signInMethod:pt.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return pt.credentialFromTaggedObject(e)}static credentialFromError(e){return pt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:s}=e;if(!t&&!s)return null;try{return pt.credential(t,s)}catch{return null}}}pt.GOOGLE_SIGN_IN_METHOD="google.com";pt.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gt extends sr{constructor(){super("github.com")}static credential(e){return Pt._fromParams({providerId:gt.PROVIDER_ID,signInMethod:gt.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return gt.credentialFromTaggedObject(e)}static credentialFromError(e){return gt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return gt.credential(e.oauthAccessToken)}catch{return null}}}gt.GITHUB_SIGN_IN_METHOD="github.com";gt.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mt extends sr{constructor(){super("twitter.com")}static credential(e,t){return Pt._fromParams({providerId:mt.PROVIDER_ID,signInMethod:mt.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return mt.credentialFromTaggedObject(e)}static credentialFromError(e){return mt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:s}=e;if(!t||!s)return null;try{return mt.credential(t,s)}catch{return null}}}mt.TWITTER_SIGN_IN_METHOD="twitter.com";mt.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ql(r,e){return rr(r,"POST","/v1/accounts:signUp",dt(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xt{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,n=!1){const i=await Ye._fromIdTokenResponse(e,s,n),a=Es(s);return new xt({user:i,providerId:a,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const n=Es(s);return new xt({user:e,providerId:n,_tokenResponse:s,operationType:t})}}function Es(r){return r.providerId?r.providerId:"phoneNumber"in r?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gr extends wt{constructor(e,t,s,n){super(t.code,t.message),this.operationType=s,this.user=n,Object.setPrototypeOf(this,gr.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:s}}static _fromErrorAndOperation(e,t,s,n){return new gr(e,t,s,n)}}function Tn(r,e,t,s){return(e==="reauthenticate"?t._getReauthenticationResolver(r):t._getIdTokenResponse(r)).catch(i=>{throw i.code==="auth/multi-factor-auth-required"?gr._fromErrorAndOperation(r,i,e,s):i})}async function Gl(r,e,t=!1){const s=await Yt(r,e._linkToIdToken(r.auth,await r.getIdToken()),t);return xt._forOperation(r,"link",s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Kl(r,e,t=!1){const{auth:s}=r;if(Ge(s.app))return Promise.reject(at(s));const n="reauthenticate";try{const i=await Yt(r,Tn(s,n,e,r),t);G(i.idToken,s,"internal-error");const a=qr(i.idToken);G(a,s,"internal-error");const{sub:o}=a;return G(r.uid===o,s,"user-mismatch"),xt._forOperation(r,n,i)}catch(i){throw(i==null?void 0:i.code)==="auth/user-not-found"&&Je(s,"user-mismatch"),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Pn(r,e,t=!1){if(Ge(r.app))return Promise.reject(at(r));const s="signIn",n=await Tn(r,s,e),i=await xt._fromIdTokenResponse(r,s,n);return t||await r._updateCurrentUser(i.user),i}async function Yl(r,e){return Pn(It(r),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function xn(r){const e=It(r);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}async function Jl(r,e,t){const s=It(r);await pr(s,{requestType:"PASSWORD_RESET",email:e,clientType:"CLIENT_TYPE_WEB"},"getOobCode",Bl)}async function Zl(r,e,t){if(Ge(r.app))return Promise.reject(at(r));const s=It(r),a=await pr(s,{returnSecureToken:!0,email:e,password:t,clientType:"CLIENT_TYPE_WEB"},"signUpPassword",ql).catch(l=>{throw l.code==="auth/password-does-not-meet-requirements"&&xn(r),l}),o=await xt._fromIdTokenResponse(s,"signIn",a);return await s._updateCurrentUser(o.user),o}function Ql(r,e,t){return Ge(r.app)?Promise.reject(at(r)):Yl(ct(r),Ut.credential(e,t)).catch(async s=>{throw s.code==="auth/password-does-not-meet-requirements"&&xn(r),s})}function Xl(r,e,t,s){return ct(r).onIdTokenChanged(e,t,s)}function ec(r,e,t){return ct(r).beforeAuthStateChanged(e,t)}function tc(r,e,t,s){return ct(r).onAuthStateChanged(e,t,s)}function rc(r){return ct(r).signOut()}const mr="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kn{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(mr,"1"),this.storage.removeItem(mr),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sc=1e3,nc=10;class An extends kn{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=_n(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const s=this.storage.getItem(t),n=this.localCache[t];s!==n&&e(t,n,s)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((a,o,l)=>{this.notifyListeners(a,l)});return}const s=e.key;t?this.detachListener():this.stopPolling();const n=()=>{const a=this.storage.getItem(s);!t&&this.localCache[s]===a||this.notifyListeners(s,a)},i=this.storage.getItem(s);_l()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(n,nc):n()}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const n of Array.from(s))n(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,s)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:s}),!0)})},sc)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}An.type="LOCAL";const ic=An;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sn extends kn{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Sn.type="SESSION";const Cn=Sn;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ac(r){return Promise.all(r.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wr{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(n=>n.isListeningto(e));if(t)return t;const s=new wr(e);return this.receivers.push(s),s}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:s,eventType:n,data:i}=t.data,a=this.handlersMap[n];if(!(a!=null&&a.size))return;t.ports[0].postMessage({status:"ack",eventId:s,eventType:n});const o=Array.from(a).map(async u=>u(t.origin,i)),l=await ac(o);t.ports[0].postMessage({status:"done",eventId:s,eventType:n,response:l})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}wr.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jr(r="",e=10){let t="";for(let s=0;s<e;s++)t+=Math.floor(Math.random()*10);return r+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oc{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,s=50){const n=typeof MessageChannel<"u"?new MessageChannel:null;if(!n)throw new Error("connection_unavailable");let i,a;return new Promise((o,l)=>{const u=Jr("",20);n.port1.start();const m=setTimeout(()=>{l(new Error("unsupported_event"))},s);a={messageChannel:n,onMessage(p){const d=p;if(d.data.eventId===u)switch(d.data.status){case"ack":clearTimeout(m),i=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),o(d.data.response);break;default:clearTimeout(m),clearTimeout(i),l(new Error("invalid_response"));break}}},this.handlers.add(a),n.port1.addEventListener("message",a.onMessage),this.target.postMessage({eventType:e,eventId:u,data:t},[n.port2])}).finally(()=>{a&&this.removeMessageHandler(a)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function et(){return window}function lc(r){et().location.href=r}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $n(){return typeof et().WorkerGlobalScope<"u"&&typeof et().importScripts=="function"}async function cc(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function dc(){var r;return((r=navigator==null?void 0:navigator.serviceWorker)==null?void 0:r.controller)||null}function uc(){return $n()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rn="firebaseLocalStorageDb",hc=1,_r="firebaseLocalStorage",On="fbase_key";class nr{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function Ir(r,e){return r.transaction([_r],e?"readwrite":"readonly").objectStore(_r)}function fc(){const r=indexedDB.deleteDatabase(Rn);return new nr(r).toPromise()}function Br(){const r=indexedDB.open(Rn,hc);return new Promise((e,t)=>{r.addEventListener("error",()=>{t(r.error)}),r.addEventListener("upgradeneeded",()=>{const s=r.result;try{s.createObjectStore(_r,{keyPath:On})}catch(n){t(n)}}),r.addEventListener("success",async()=>{const s=r.result;s.objectStoreNames.contains(_r)?e(s):(s.close(),await fc(),e(await Br()))})})}async function Ts(r,e,t){const s=Ir(r,!0).put({[On]:e,value:t});return new nr(s).toPromise()}async function vc(r,e){const t=Ir(r,!1).get(e),s=await new nr(t).toPromise();return s===void 0?null:s.value}function Ps(r,e){const t=Ir(r,!0).delete(e);return new nr(t).toPromise()}const pc=800,gc=3;class Mn{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await Br(),this.db)}async _withRetries(e){let t=0;for(;;)try{const s=await this._openDb();return await e(s)}catch(s){if(t++>gc)throw s;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return $n()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=wr._getInstance(uc()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,s;if(this.activeServiceWorker=await cc(),!this.activeServiceWorker)return;this.sender=new oc(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(s=e[0])!=null&&s.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||dc()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await Br();return await Ts(e,mr,"1"),await Ps(e,mr),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(s=>Ts(s,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(s=>vc(s,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Ps(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(n=>{const i=Ir(n,!1).getAll();return new nr(i).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],s=new Set;if(e.length!==0)for(const{fbase_key:n,value:i}of e)s.add(n),JSON.stringify(this.localCache[n])!==JSON.stringify(i)&&(this.notifyListeners(n,i),t.push(n));for(const n of Object.keys(this.localCache))this.localCache[n]&&!s.has(n)&&(this.notifyListeners(n,null),t.push(n));return t}notifyListeners(e,t){this.localCache[e]=t;const s=this.listeners[e];if(s)for(const n of Array.from(s))n(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),pc)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Mn.type="LOCAL";const mc=Mn;new tr(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _c(r,e){return e?it(e):(G(r._popupRedirectResolver,r,"argument-error"),r._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zr extends Kr{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Ot(e,this._buildIdpRequest())}_linkToIdToken(e,t){return Ot(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return Ot(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function bc(r){return Pn(r.auth,new Zr(r),r.bypassAuthState)}function yc(r){const{auth:e,user:t}=r;return G(t,e,"internal-error"),Kl(t,new Zr(r),r.bypassAuthState)}async function wc(r){const{auth:e,user:t}=r;return G(t,e,"internal-error"),Gl(t,new Zr(r),r.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dn{constructor(e,t,s,n,i=!1){this.auth=e,this.resolver=s,this.user=n,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(s){this.reject(s)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:s,postBody:n,tenantId:i,error:a,type:o}=e;if(a){this.reject(a);return}const l={auth:this.auth,requestUri:t,sessionId:s,tenantId:i||void 0,postBody:n||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(o)(l))}catch(u){this.reject(u)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return bc;case"linkViaPopup":case"linkViaRedirect":return wc;case"reauthViaPopup":case"reauthViaRedirect":return yc;default:Je(this.auth,"internal-error")}}resolve(e){lt(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){lt(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ic=new tr(2e3,1e4);class St extends Dn{constructor(e,t,s,n,i){super(e,t,n,i),this.provider=s,this.authWindow=null,this.pollId=null,St.currentPopupAction&&St.currentPopupAction.cancel(),St.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return G(e,this.auth,"internal-error"),e}async onExecution(){lt(this.filter.length===1,"Popup operations only handle one event");const e=Jr();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Xe(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(Xe(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,St.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,s;if((s=(t=this.authWindow)==null?void 0:t.window)!=null&&s.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Xe(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,Ic.get())};e()}}St.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ec="pendingRedirect",lr=new Map;class Tc extends Dn{constructor(e,t,s=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,s),this.eventId=null}async execute(){let e=lr.get(this.auth._key());if(!e){try{const s=await Pc(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(s)}catch(t){e=()=>Promise.reject(t)}lr.set(this.auth._key(),e)}return this.bypassAuthState||lr.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function Pc(r,e){const t=Ac(e),s=kc(r);if(!await s._isAvailable())return!1;const n=await s._get(t)==="true";return await s._remove(t),n}function xc(r,e){lr.set(r._key(),e)}function kc(r){return it(r._redirectPersistence)}function Ac(r){return or(Ec,r.config.apiKey,r.name)}async function Sc(r,e,t=!1){if(Ge(r.app))return Promise.reject(at(r));const s=It(r),n=_c(s,e),a=await new Tc(s,n,t).execute();return a&&!t&&(delete a.user._redirectEventId,await s._persistUserIfCurrent(a.user),await s._setRedirectUser(null,e)),a}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cc=10*60*1e3;class $c{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(s=>{this.isEventForConsumer(e,s)&&(t=!0,this.sendToConsumer(e,s),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!Rc(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var s;if(e.error&&!Nn(e)){const n=((s=e.error.code)==null?void 0:s.split("auth/")[1])||"internal-error";t.onError(Xe(this.auth,n))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const s=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&s}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=Cc&&this.cachedEventUids.clear(),this.cachedEventUids.has(xs(e))}saveEventToCache(e){this.cachedEventUids.add(xs(e)),this.lastProcessedEventTime=Date.now()}}function xs(r){return[r.type,r.eventId,r.sessionId,r.tenantId].filter(e=>e).join("-")}function Nn({type:r,error:e}){return r==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function Rc(r){switch(r.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Nn(r);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Oc(r,e={}){return ut(r,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mc=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Dc=/^https?/;async function Nc(r){if(r.config.emulator)return;const{authorizedDomains:e}=await Oc(r);for(const t of e)try{if(Lc(t))return}catch{}Je(r,"unauthorized-domain")}function Lc(r){const e=Ur(),{protocol:t,hostname:s}=new URL(e);if(r.startsWith("chrome-extension://")){const a=new URL(r);return a.hostname===""&&s===""?t==="chrome-extension:"&&r.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&a.hostname===s}if(!Dc.test(t))return!1;if(Mc.test(r))return s===r;const n=r.replace(/\./g,"\\.");return new RegExp("^(.+\\."+n+"|"+n+")$","i").test(s)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Uc=new tr(3e4,6e4);function ks(){const r=et().___jsl;if(r!=null&&r.H){for(const e of Object.keys(r.H))if(r.H[e].r=r.H[e].r||[],r.H[e].L=r.H[e].L||[],r.H[e].r=[...r.H[e].L],r.CP)for(let t=0;t<r.CP.length;t++)r.CP[t]=null}}function Hc(r){return new Promise((e,t)=>{var n,i,a;function s(){ks(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{ks(),t(Xe(r,"network-request-failed"))},timeout:Uc.get()})}if((i=(n=et().gapi)==null?void 0:n.iframes)!=null&&i.Iframe)e(gapi.iframes.getContext());else if((a=et().gapi)!=null&&a.load)s();else{const o=kl("iframefcb");return et()[o]=()=>{gapi.load?s():t(Xe(r,"network-request-failed"))},yn(`${xl()}?onload=${o}`).catch(l=>t(l))}}).catch(e=>{throw cr=null,e})}let cr=null;function Bc(r){return cr=cr||Hc(r),cr}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vc=new tr(5e3,15e3),zc="__/auth/iframe",Fc="emulator/auth/iframe",Wc={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},jc=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function qc(r){const e=r.config;G(e.authDomain,r,"auth-domain-config-required");const t=e.emulator?jr(e,Fc):`https://${r.config.authDomain}/${zc}`,s={apiKey:e.apiKey,appName:r.name,v:er},n=jc.get(r.config.apiHost);n&&(s.eid=n);const i=r._getFrameworks();return i.length&&(s.fw=i.join(",")),`${t}?${Xt(s).slice(1)}`}async function Gc(r){const e=await Bc(r),t=et().gapi;return G(t,r,"internal-error"),e.open({where:document.body,url:qc(r),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:Wc,dontclear:!0},s=>new Promise(async(n,i)=>{await s.restyle({setHideOnLeave:!1});const a=Xe(r,"network-request-failed"),o=et().setTimeout(()=>{i(a)},Vc.get());function l(){et().clearTimeout(o),n(s)}s.ping(l).then(l,()=>{i(a)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kc={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},Yc=500,Jc=600,Zc="_blank",Qc="http://localhost";class As{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function Xc(r,e,t,s=Yc,n=Jc){const i=Math.max((window.screen.availHeight-n)/2,0).toString(),a=Math.max((window.screen.availWidth-s)/2,0).toString();let o="";const l={...Kc,width:s.toString(),height:n.toString(),top:i,left:a},u=Be().toLowerCase();t&&(o=fn(u)?Zc:t),un(u)&&(e=e||Qc,l.scrollbars="yes");const m=Object.entries(l).reduce((d,[_,y])=>`${d}${_}=${y},`,"");if(ml(u)&&o!=="_self")return ed(e||"",o),new As(null);const p=window.open(e||"",o,m);G(p,r,"popup-blocked");try{p.focus()}catch{}return new As(p)}function ed(r,e){const t=document.createElement("a");t.href=r,t.target=e;const s=document.createEvent("MouseEvent");s.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(s)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const td="__/auth/handler",rd="emulator/auth/handler",sd=encodeURIComponent("fac");async function Ss(r,e,t,s,n,i){G(r.config.authDomain,r,"auth-domain-config-required"),G(r.config.apiKey,r,"invalid-api-key");const a={apiKey:r.config.apiKey,appName:r.name,authType:t,redirectUrl:s,v:er,eventId:n};if(e instanceof En){e.setDefaultLanguage(r.languageCode),a.providerId=e.providerId||"",Da(e.getCustomParameters())||(a.customParameters=JSON.stringify(e.getCustomParameters()));for(const[m,p]of Object.entries({}))a[m]=p}if(e instanceof sr){const m=e.getScopes().filter(p=>p!=="");m.length>0&&(a.scopes=m.join(","))}r.tenantId&&(a.tid=r.tenantId);const o=a;for(const m of Object.keys(o))o[m]===void 0&&delete o[m];const l=await r._getAppCheckToken(),u=l?`#${sd}=${encodeURIComponent(l)}`:"";return`${nd(r)}?${Xt(o).slice(1)}${u}`}function nd({config:r}){return r.emulator?jr(r,rd):`https://${r.authDomain}/${td}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rr="webStorageSupport";class id{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Cn,this._completeRedirectFn=Sc,this._overrideRedirectResult=xc}async _openPopup(e,t,s,n){var a;lt((a=this.eventManagers[e._key()])==null?void 0:a.manager,"_initialize() not called before _openPopup()");const i=await Ss(e,t,s,Ur(),n);return Xc(e,i,Jr())}async _openRedirect(e,t,s,n){await this._originValidation(e);const i=await Ss(e,t,s,Ur(),n);return lc(i),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:n,promise:i}=this.eventManagers[t];return n?Promise.resolve(n):(lt(i,"If manager is not set, promise should be"),i)}const s=this.initAndGetManager(e);return this.eventManagers[t]={promise:s},s.catch(()=>{delete this.eventManagers[t]}),s}async initAndGetManager(e){const t=await Gc(e),s=new $c(e);return t.register("authEvent",n=>(G(n==null?void 0:n.authEvent,e,"invalid-auth-event"),{status:s.onEvent(n.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:s},this.iframes[e._key()]=t,s}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(Rr,{type:Rr},n=>{var a;const i=(a=n==null?void 0:n[0])==null?void 0:a[Rr];i!==void 0&&t(!!i),Je(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=Nc(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return _n()||hn()||Gr()}}const ad=id;var Cs="@firebase/auth",$s="1.12.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class od{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){G(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ld(r){switch(r){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function cd(r){Gt(new Nt("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),n=e.getProvider("heartbeat"),i=e.getProvider("app-check-internal"),{apiKey:a,authDomain:o}=s.options;G(a&&!a.includes(":"),"invalid-api-key",{appName:s.name});const l={apiKey:a,authDomain:o,clientPlatform:r,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:bn(r)},u=new El(s,n,i,l);return Ol(u,t),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),Gt(new Nt("auth-internal",e=>{const t=It(e.getProvider("auth").getImmediate());return(s=>new od(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Ct(Cs,$s,ld(r)),Ct(Cs,$s,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dd=5*60,ud=Ks("authIdTokenMaxAge")||dd;let Rs=null;const hd=r=>async e=>{const t=e&&await e.getIdTokenResult(),s=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(s&&s>ud)return;const n=t==null?void 0:t.token;Rs!==n&&(Rs=n,await fetch(r,{method:n?"POST":"DELETE",headers:n?{Authorization:`Bearer ${n}`}:{}}))};function fd(r=Uo()){const e=Qs(r,"auth");if(e.isInitialized())return e.getImmediate();const t=Rl(r,{popupRedirectResolver:ad,persistence:[mc,ic,Cn]}),s=Ks("authTokenSyncURL");if(s&&typeof isSecureContext=="boolean"&&isSecureContext){const i=new URL(s,location.origin);if(location.origin===i.origin){const a=hd(i.toString());ec(t,a,()=>a(t.currentUser)),Xl(t,o=>a(o))}}const n=ba("auth");return n&&Ml(t,`http://${n}`),t}function vd(){var r;return((r=document.getElementsByTagName("head"))==null?void 0:r[0])??document}Tl({loadJS(r){return new Promise((e,t)=>{const s=document.createElement("script");s.setAttribute("src",r),s.onload=e,s.onerror=n=>{const i=Xe("internal-error");i.customData=n,t(i)},s.type="text/javascript",s.charset="UTF-8",vd().appendChild(s)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});cd("Browser");const pd={apiKey:"AIzaSyDy5zDOy9WuqAoiZpacrojs0qJlSVdb9c8",authDomain:"elastotool-authentification.firebaseapp.com",projectId:"elastotool-authentification",storageBucket:"elastotool-authentification.firebasestorage.app",messagingSenderId:"312737503016",appId:"1:312737503016:web:fa5179d68617b63287621d"},gd=Xs(pd),qt=fd(gd);var md=T('<div class="form-content svelte-ibo97i"><!> <!> <!> <div class="links svelte-ibo97i"><!> <span class="separator svelte-ibo97i">|</span> <!></div></div>'),_d=T('<div class="form-content svelte-ibo97i"><!> <!> <!> <!> <div class="links svelte-ibo97i"><!></div></div>'),bd=T('<div class="form-content svelte-ibo97i"><p class="reset-info svelte-ibo97i">Geben Sie Ihre E-Mail-Adresse ein und wir senden Ihnen einen Link zum Zurücksetzen Ihres Passworts.</p> <!> <!> <div class="links svelte-ibo97i"><!></div></div>'),yd=T('<div class="login-container svelte-ibo97i" role="form"><div class="login-card svelte-ibo97i"><div class="login-header svelte-ibo97i"><h1 class="svelte-ibo97i">ElastoTool</h1> <p class="subtitle svelte-ibo97i"><!></p></div> <!> <!> <!></div></div>');function wd(r,e){we(e,!0);let t=qe("login"),s=qe(""),n=qe(""),i=qe(""),a=qe(!1),o=qe(""),l=qe("");function u(){$(o,""),$(l,"")}function m(){$(s,""),$(n,""),$(i,""),u()}function p(x){$(t,x,!0),m()}async function d(){if(u(),!c(s)||!c(n)){$(o,"Bitte füllen Sie alle Felder aus.");return}$(a,!0);try{await Ql(qt,c(s),c(n))}catch(x){$(o,C(x.code),!0)}finally{$(a,!1)}}async function _(){if(u(),!c(s)||!c(n)||!c(i)){$(o,"Bitte füllen Sie alle Felder aus.");return}if(c(n)!==c(i)){$(o,"Die Passwörter stimmen nicht überein.");return}if(c(n).length<6){$(o,"Das Passwort muss mindestens 6 Zeichen lang sein.");return}$(a,!0);try{await Zl(qt,c(s),c(n))}catch(x){$(o,C(x.code),!0)}finally{$(a,!1)}}async function y(){if(u(),!c(s)){$(o,"Bitte geben Sie Ihre E-Mail-Adresse ein.");return}$(a,!0);try{await Jl(qt,c(s)),$(l,"Eine E-Mail zum Zurücksetzen des Passworts wurde gesendet. Bitte überprüfen Sie Ihren Posteingang.")}catch(x){$(o,C(x.code),!0)}finally{$(a,!1)}}function C(x){switch(x){case"auth/invalid-email":return"Ungültige E-Mail-Adresse.";case"auth/user-disabled":return"Dieses Benutzerkonto wurde deaktiviert.";case"auth/user-not-found":return"Kein Benutzer mit dieser E-Mail-Adresse gefunden.";case"auth/wrong-password":return"Falsches Passwort.";case"auth/invalid-credential":return"Ungültige Anmeldedaten. Bitte überprüfen Sie Ihre E-Mail und Ihr Passwort.";case"auth/email-already-in-use":return"Diese E-Mail-Adresse wird bereits verwendet.";case"auth/weak-password":return"Das Passwort ist zu schwach. Bitte wählen Sie ein stärkeres Passwort.";case"auth/too-many-requests":return"Zu viele Anmeldeversuche. Bitte versuchen Sie es später erneut.";case"auth/network-request-failed":return"Netzwerkfehler. Bitte überprüfen Sie Ihre Internetverbindung.";default:return"Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut."}}function I(x){x.key==="Enter"&&(c(t)==="login"?d():c(t)==="register"?_():c(t)==="reset"&&y())}var w=yd(),S=f(w),M=f(S),O=g(f(M),2),b=f(O);{var j=x=>{var z=ce("Melden Sie sich an, um fortzufahren");v(x,z)},V=(x,z)=>{{var fe=J=>{var te=ce("Erstellen Sie ein neues Konto");v(J,te)},ye=J=>{var te=ce("Passwort zurücksetzen");v(J,te)};N(x,J=>{c(t)==="register"?J(fe):J(ye,!1)},z)}};N(b,x=>{c(t)==="login"?x(j):x(V,!1)})}h(O),h(M);var H=g(M,2);{var A=x=>{ts(x,{kind:"error",title:"Fehler",get subtitle(){return c(o)},hideCloseButton:!0})};N(H,x=>{c(o)&&x(A)})}var k=g(H,2);{var B=x=>{ts(x,{kind:"success",title:"Erfolg",get subtitle(){return c(l)},hideCloseButton:!0})};N(k,x=>{c(l)&&x(B)})}var U=g(k,2);{var F=x=>{var z=md(),fe=f(z);Tr(fe,{labelText:"E-Mail-Adresse",placeholder:"ihre.email@beispiel.de",type:"email",get disabled(){return c(a)},get value(){return c(s)},set value(X){$(s,X,!0)}});var ye=g(fe,2);Pr(ye,{labelText:"Passwort",placeholder:"Passwort eingeben",get disabled(){return c(a)},get value(){return c(n)},set value(X){$(n,X,!0)}});var J=g(ye,2);st(J,{kind:"secondary",get disabled(){return c(a)},class:"submit-button",$$events:{click:d},children:(X,ve)=>{W();var Te=ce();R(()=>P(Te,c(a)?"Wird angemeldet...":"Anmelden")),v(X,Te)},$$slots:{default:!0}});var te=g(J,2),le=f(te);Bt(le,{$$events:{click:()=>p("reset")},children:(X,ve)=>{W();var Te=ce("Passwort vergessen?");v(X,Te)},$$slots:{default:!0}});var de=g(le,4);Bt(de,{$$events:{click:()=>p("register")},children:(X,ve)=>{W();var Te=ce("Konto erstellen");v(X,Te)},$$slots:{default:!0}}),h(te),h(z),v(x,z)},L=(x,z)=>{{var fe=J=>{var te=_d(),le=f(te);Tr(le,{labelText:"E-Mail-Adresse",placeholder:"ihre.email@beispiel.de",type:"email",get disabled(){return c(a)},get value(){return c(s)},set value(pe){$(s,pe,!0)}});var de=g(le,2);Pr(de,{labelText:"Passwort",placeholder:"Passwort eingeben (min. 6 Zeichen)",get disabled(){return c(a)},get value(){return c(n)},set value(pe){$(n,pe,!0)}});var X=g(de,2);Pr(X,{labelText:"Passwort bestätigen",placeholder:"Passwort erneut eingeben",get disabled(){return c(a)},get value(){return c(i)},set value(pe){$(i,pe,!0)}});var ve=g(X,2);st(ve,{kind:"secondary",get disabled(){return c(a)},class:"submit-button",$$events:{click:_},children:(pe,xe)=>{W();var _e=ce();R(()=>P(_e,c(a)?"Wird registriert...":"Registrieren")),v(pe,_e)},$$slots:{default:!0}});var Te=g(ve,2),Pe=f(Te);Bt(Pe,{$$events:{click:()=>p("login")},children:(pe,xe)=>{W();var _e=ce("Bereits ein Konto? Anmelden");v(pe,_e)},$$slots:{default:!0}}),h(Te),h(te),v(J,te)},ye=(J,te)=>{{var le=de=>{var X=bd(),ve=g(f(X),2);Tr(ve,{labelText:"E-Mail-Adresse",placeholder:"ihre.email@beispiel.de",type:"email",get disabled(){return c(a)},get value(){return c(s)},set value(xe){$(s,xe,!0)}});var Te=g(ve,2);st(Te,{kind:"secondary",get disabled(){return c(a)},class:"submit-button",$$events:{click:y},children:(xe,_e)=>{W();var Fe=ce();R(()=>P(Fe,c(a)?"Wird gesendet...":"Link senden")),v(xe,Fe)},$$slots:{default:!0}});var Pe=g(Te,2),pe=f(Pe);Bt(pe,{$$events:{click:()=>p("login")},children:(xe,_e)=>{W();var Fe=ce("Zurück zur Anmeldung");v(xe,Fe)},$$slots:{default:!0}}),h(Pe),h(X),v(de,X)};N(J,de=>{c(t)==="reset"&&de(le)},te)}};N(x,J=>{c(t)==="register"?J(fe):J(ye,!1)},z)}};N(U,x=>{c(t)==="login"?x(F):x(L,!1)})}h(S),h(w),oe("keypress",w,I),v(r,w),Ie()}var Id=T('<div class="content-wrapper svelte-1mt858d"><!></div>');function At(r,e){E(e,"backLabel",3,"BACK"),E(e,"actionLabel",3,""),Qn(r,{class:"content-container",style:"background-color: #f4f7f6; padding: 2rem; margin:0",children:(t,s)=>{var n=Id(),i=f(n);Le(i,{light:!0,children:(a,o)=>{var l=ze(),u=q(l);Zn(u,()=>e.children),v(a,l)},$$slots:{default:!0}}),h(n),v(t,n)},$$slots:{default:!0}})}var Ed=T('<h1 class="page-title svelte-k0pwcb">Dashboard</h1> <p class="page-subtitle svelte-k0pwcb">Overview of your business metrics</p>',1),Td=T('<p class="metric-label svelte-k0pwcb">Total Orders</p> <p class="metric-value svelte-k0pwcb">156</p> <p class="metric-change positive svelte-k0pwcb">+12% from last month</p>',1),Pd=T('<p class="metric-label svelte-k0pwcb">Active Quotes</p> <p class="metric-value svelte-k0pwcb">23</p> <p class="metric-change positive svelte-k0pwcb">+5% from last month</p>',1),xd=T('<p class="metric-label svelte-k0pwcb">Pending Requests</p> <p class="metric-value svelte-k0pwcb">8</p> <p class="metric-change negative svelte-k0pwcb">-3% from last month</p>',1),kd=T('<p class="metric-label svelte-k0pwcb">Revenue</p> <p class="metric-value svelte-k0pwcb">$248,500</p> <p class="metric-change positive svelte-k0pwcb">+18% from last month</p>',1),Ad=T("<!> <!> <!> <!>",1),Sd=T('<h3 class="section-title svelte-k0pwcb">Recent Activity</h3> <ul class="activity-list svelte-k0pwcb"><li class="svelte-k0pwcb">Order #27051941 shipped to TIMBER DEPOT</li> <li class="svelte-k0pwcb">New quote requested by LUMBER COMPANY</li> <li class="svelte-k0pwcb">Payment received for Order #27041938</li> <li class="svelte-k0pwcb">Product catalog updated with 12 new items</li></ul>',1),Cd=T('<h3 class="section-title svelte-k0pwcb">Quick Actions</h3> <div class="quick-actions svelte-k0pwcb"><!> <!> <!></div>',1),$d=T("<!> <!>",1),Rd=T("<!> <!> <!>",1);function Os(r){At(r,{backLabel:"",actionLabel:"",children:(e,t)=>{var s=Rd(),n=q(s);Se(n,{children:(o,l)=>{se(o,{lg:16,children:(u,m)=>{var p=Ed();W(2),v(u,p)},$$slots:{default:!0}})},$$slots:{default:!0}});var i=g(n,2);Se(i,{children:(o,l)=>{var u=Ad(),m=q(u);se(m,{lg:4,md:4,sm:4,children:(y,C)=>{Le(y,{light:!0,class:"metric-tile",children:(I,w)=>{var S=Td();W(4),v(I,S)},$$slots:{default:!0}})},$$slots:{default:!0}});var p=g(m,2);se(p,{lg:4,md:4,sm:4,children:(y,C)=>{Le(y,{light:!0,class:"metric-tile",children:(I,w)=>{var S=Pd();W(4),v(I,S)},$$slots:{default:!0}})},$$slots:{default:!0}});var d=g(p,2);se(d,{lg:4,md:4,sm:4,children:(y,C)=>{Le(y,{light:!0,class:"metric-tile",children:(I,w)=>{var S=xd();W(4),v(I,S)},$$slots:{default:!0}})},$$slots:{default:!0}});var _=g(d,2);se(_,{lg:4,md:4,sm:4,children:(y,C)=>{Le(y,{light:!0,class:"metric-tile",children:(I,w)=>{var S=kd();W(4),v(I,S)},$$slots:{default:!0}})},$$slots:{default:!0}}),v(o,u)},$$slots:{default:!0}});var a=g(i,2);Se(a,{children:(o,l)=>{var u=$d(),m=q(u);se(m,{lg:8,md:8,sm:4,children:(d,_)=>{Le(d,{light:!0,children:(y,C)=>{var I=Sd();W(2),v(y,I)},$$slots:{default:!0}})},$$slots:{default:!0}});var p=g(m,2);se(p,{lg:8,md:8,sm:4,children:(d,_)=>{Le(d,{light:!0,children:(y,C)=>{var I=Cd(),w=g(q(I),2),S=f(w);Ft(S,{children:(b,j)=>{W();var V=ce("Create New Quote");v(b,V)},$$slots:{default:!0}});var M=g(S,2);Ft(M,{children:(b,j)=>{W();var V=ce("Add Product");v(b,V)},$$slots:{default:!0}});var O=g(M,2);Ft(O,{children:(b,j)=>{W();var V=ce("View Reports");v(b,V)},$$slots:{default:!0}}),h(w),v(y,I)},$$slots:{default:!0}})},$$slots:{default:!0}}),v(o,u)},$$slots:{default:!0}}),v(e,s)},$$slots:{default:!0}})}var Od=T('<h1 class="page-title svelte-1cf4os2">Chats</h1> <p class="page-subtitle svelte-1cf4os2">Customer conversations</p>',1),Md=T('<div><div class="chat-avatar svelte-1cf4os2"> </div> <div class="chat-info svelte-1cf4os2"><div class="chat-header svelte-1cf4os2"><span class="chat-name svelte-1cf4os2"> </span> <span class="chat-time svelte-1cf4os2"> </span></div> <div class="chat-preview svelte-1cf4os2"><span class="chat-message svelte-1cf4os2"> </span> <!></div></div></div>'),Dd=T('<div class="chat-list svelte-1cf4os2"><div class="search-wrapper svelte-1cf4os2"><!></div> <!></div>'),Nd=T('<div class="chat-window-header svelte-1cf4os2"><div class="chat-avatar large svelte-1cf4os2">L</div> <div><p class="chat-window-name svelte-1cf4os2">LUMBER COMPANY</p> <p class="chat-window-status svelte-1cf4os2">Online</p></div></div> <div class="chat-messages svelte-1cf4os2"><div class="message received svelte-1cf4os2"><p class="svelte-1cf4os2">Hi, I wanted to follow up on our recent order.</p> <span class="message-time svelte-1cf4os2">10:28 AM</span></div> <div class="message sent svelte-1cf4os2"><p class="svelte-1cf4os2">Of course! Order #27051941 is currently being prepared for shipment.</p> <span class="message-time svelte-1cf4os2">10:30 AM</span></div> <div class="message received svelte-1cf4os2"><p class="svelte-1cf4os2">Thanks for the quick response!</p> <span class="message-time svelte-1cf4os2">10:32 AM</span></div></div> <div class="chat-input svelte-1cf4os2"><input type="text" placeholder="Type a message..." class="svelte-1cf4os2"/></div>',1),Ld=T("<!> <!>",1),Ud=T("<!> <!>",1);function Hd(r){const e=[{id:1,name:"LUMBER COMPANY",lastMessage:"Thanks for the quick response!",time:"10:32 AM",unread:2},{id:2,name:"TIMBER DEPOT",lastMessage:"When can we expect the shipment?",time:"Yesterday",unread:0},{id:3,name:"WOODWORKS INC",lastMessage:"Please send the updated quote",time:"Yesterday",unread:1},{id:4,name:"FOREST SUPPLIES",lastMessage:"Order confirmed, thank you!",time:"2 days ago",unread:0},{id:5,name:"PINE TRADERS",lastMessage:"Can you match this price?",time:"3 days ago",unread:0}];At(r,{backLabel:"",actionLabel:"New Chat",children:(t,s)=>{var n=Ud(),i=q(n);Se(i,{children:(o,l)=>{se(o,{lg:16,children:(u,m)=>{var p=Od();W(2),v(u,p)},$$slots:{default:!0}})},$$slots:{default:!0}});var a=g(i,2);Se(a,{children:(o,l)=>{var u=Ld(),m=q(u);se(m,{lg:5,md:8,sm:4,children:(d,_)=>{var y=Dd(),C=f(y),I=f(C);Vr(I,{placeholder:"Search conversations..."}),h(C);var w=g(C,2);kt(w,1,()=>e,Lt,(S,M)=>{var O=Md();let b;var j=f(O),V=f(j,!0);h(j);var H=g(j,2),A=f(H),k=f(A),B=f(k,!0);h(k);var U=g(k,2),F=f(U,!0);h(U),h(A);var L=g(A,2),x=f(L),z=f(x,!0);h(x);var fe=g(x,2);{var ye=J=>{Zt(J,{type:"blue",size:"sm",children:(te,le)=>{W();var de=ce();R(()=>P(de,c(M).unread)),v(te,de)},$$slots:{default:!0}})};N(fe,J=>{c(M).unread>0&&J(ye)})}h(L),h(H),h(O),R((J,te)=>{b=Ae(O,1,"chat-item svelte-1cf4os2",null,b,J),P(V,te),P(B,c(M).name),P(F,c(M).time),P(z,c(M).lastMessage)},[()=>({unread:c(M).unread>0}),()=>c(M).name.charAt(0)],ae),v(S,O)}),h(y),v(d,y)},$$slots:{default:!0}});var p=g(m,2);se(p,{lg:11,md:8,sm:4,children:(d,_)=>{Le(d,{class:"chat-window",children:(y,C)=>{var I=Nd();W(4),v(y,I)},$$slots:{default:!0}})},$$slots:{default:!0}}),v(o,u)},$$slots:{default:!0}}),v(t,n)},$$slots:{default:!0}})}var Bd=T('<dt class="svelte-1nmltxe">Lieferdatum</dt> <dd class="svelte-1nmltxe"> </dd>',1),Vd=T('<dt class="svelte-1nmltxe">Führungslager</dt> <dd class="svelte-1nmltxe"> </dd>',1),zd=T('<dt class="svelte-1nmltxe">Festpunktlager</dt> <dd class="svelte-1nmltxe"> </dd>',1),Fd=T('<span class="chip svelte-1nmltxe"> </span>'),Wd=T('<section class="detail-section full-width svelte-1nmltxe"><h4 class="svelte-1nmltxe">Zusätzliche Anmerkungen</h4> <p class="notes svelte-1nmltxe"> </p></section>'),jd=T('<div class="detail-grid svelte-1nmltxe"><section class="detail-section svelte-1nmltxe"><h4 class="svelte-1nmltxe">Allgemeine Informationen</h4> <dl class="svelte-1nmltxe"><dt class="svelte-1nmltxe">Anfrage-ID</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Erstellt am</dt> <dd class="svelte-1nmltxe"> </dd></dl></section> <section class="detail-section svelte-1nmltxe"><h4 class="svelte-1nmltxe">Kontaktdaten</h4> <dl class="svelte-1nmltxe"><dt class="svelte-1nmltxe">Name</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">E-Mail</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Firma</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Rolle</dt> <dd class="svelte-1nmltxe"> </dd></dl></section> <section class="detail-section svelte-1nmltxe"><h4 class="svelte-1nmltxe">Projektinformationen</h4> <dl class="svelte-1nmltxe"><dt class="svelte-1nmltxe">Projektname</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">PLZ</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Projektphase</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Anfragetyp</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Bauwerkstyp</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Überbau Material</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Unterbau Material</dt> <dd class="svelte-1nmltxe"> </dd> <!></dl></section> <section class="detail-section svelte-1nmltxe"><h4 class="svelte-1nmltxe">Lagerpositionen</h4> <dl class="svelte-1nmltxe"><dt class="svelte-1nmltxe">Allseitig beweglich</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Einseitig geführt</dt> <dd class="svelte-1nmltxe"> </dd> <dt class="svelte-1nmltxe">Allseitig fest</dt> <dd class="svelte-1nmltxe"> </dd> <!> <!></dl></section> <section class="detail-section full-width svelte-1nmltxe"><h4 class="svelte-1nmltxe">Angefragte Hersteller</h4> <div class="manufacturer-chips svelte-1nmltxe"></div></section> <!></div>');function qd(r,e){we(e,!1);let t=E(e,"open",12,!1),s=E(e,"request",8,null);function n(o){return new Date(o).toLocaleDateString("de-DE",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})}function i(o){return Kn.filter(l=>o[l.id]).map(l=>l.name)}Re();const a=ae(()=>{var o;return((o=s())==null?void 0:o.data.projectName)||"Anfrage Details"});Gn(r,{get modalHeading(){return c(a)},passiveModal:!0,size:"lg",get open(){return t()},set open(o){t(o)},children:(o,l)=>{var u=ze(),m=q(u);{var p=d=>{var _=jd(),y=f(_),C=g(f(y),2),I=g(f(C),2),w=f(I,!0);h(I);var S=g(I,4),M=f(S,!0);h(S),h(C),h(y);var O=g(y,2),b=g(f(O),2),j=g(f(b),2),V=f(j,!0);h(j);var H=g(j,4),A=f(H,!0);h(H);var k=g(H,4),B=f(k,!0);h(k);var U=g(k,4),F=f(U,!0);h(U),h(b),h(O);var L=g(O,2),x=g(f(L),2),z=g(f(x),2),fe=f(z,!0);h(z);var ye=g(z,4),J=f(ye,!0);h(ye);var te=g(ye,4),le=f(te,!0);h(te);var de=g(te,4),X=f(de,!0);h(de);var ve=g(de,4),Te=f(ve);h(ve);var Pe=g(ve,4),pe=f(Pe,!0);h(Pe);var xe=g(Pe,4),_e=f(xe,!0);h(xe);var Fe=g(xe,2);{var ue=Y=>{var Ee=Bd(),Ce=g(q(Ee),2),Me=f(Ce,!0);h(Ce),R(()=>P(Me,s().data.deliveryDate)),v(Y,Ee)};N(Fe,Y=>{s().data.deliveryDate&&Y(ue)})}h(x),h(L);var re=g(L,2),Ne=g(f(re),2),We=g(f(Ne),2),tt=f(We,!0);h(We);var rt=g(We,4),Ht=f(rt,!0);h(rt);var Oe=g(rt,4),ht=f(Oe,!0);h(Oe);var D=g(Oe,2);{var Z=Y=>{var Ee=Vd(),Ce=g(q(Ee),2),Me=f(Ce);h(Ce),R(()=>P(Me,`${s().data.guideBearingCount??""} (Vyd: ${s().data.guideBearingVyd??""} kN)`)),v(Y,Ee)};N(D,Y=>{s().data.guideBearingCount>0&&Y(Z)})}var ge=g(D,2);{var Ue=Y=>{var Ee=zd(),Ce=g(q(Ee),2),Me=f(Ce);h(Ce),R(()=>P(Me,`${s().data.fixedPointCount??""} (Vxd: ${s().data.fixedPointVxd??""} kN, Vyd: ${s().data.fixedPointVyd??""} kN)`)),v(Y,Ee)};N(ge,Y=>{s().data.fixedPointCount>0&&Y(Ue)})}h(Ne),h(re);var He=g(re,2),je=g(f(He),2);kt(je,5,()=>i(s().data.manufacturers),Lt,(Y,Ee)=>{var Ce=Fd(),Me=f(Ce,!0);h(Ce),R(()=>P(Me,c(Ee))),v(Y,Ce)}),h(je),h(He);var ie=g(He,2);{var me=Y=>{var Ee=Wd(),Ce=g(f(Ee),2),Me=f(Ce,!0);h(Ce),h(Ee),R(()=>P(Me,s().data.additionalNotes)),v(Y,Ee)};N(ie,Y=>{s().data.additionalNotes&&Y(me)})}h(_),R(Y=>{P(w,s().id),P(M,Y),P(V,s().data.name),P(A,s().data.email),P(B,s().data.company),P(F,s().data.role),P(fe,s().data.projectName),P(J,s().data.postalCode),P(le,s().data.projectPhase),P(X,s().data.requestType),P(Te,`${s().data.structureType??""}${s().data.structureSubtype?` - ${s().data.structureSubtype}`:""}`),P(pe,s().data.superstructureMaterial),P(_e,s().data.substructureMaterial),P(tt,s().data.movableAllDirections),P(Ht,s().data.laterallyFixed),P(ht,s().data.fixedAllDirections)},[()=>n(s().createdAt)],ae),v(d,_)};N(m,d=>{s()&&d(p)})}v(o,u)},$$slots:{default:!0},$$legacy:!0}),Ie()}var Gd=T('<h1 class="page-title svelte-11vrnrd">Meine Anfragen</h1> <p class="page-subtitle svelte-11vrnrd">Verwalten Sie Ihre Herstelleranfragen</p>',1),Kd=T('<button class="request-link svelte-11vrnrd"> </button>'),Yd=T('<div class="empty-state svelte-11vrnrd"><p class="svelte-11vrnrd">Noch keine Anfragen vorhanden.</p> <p class="empty-hint svelte-11vrnrd">Erstellen Sie eine neue Herstelleranfrage über das Brückenlager-Tool.</p></div>'),Jd=T('<div class="stats-row svelte-11vrnrd"><div class="stat-item svelte-11vrnrd"><span class="stat-value svelte-11vrnrd"> </span> <span class="stat-label svelte-11vrnrd">Gesamt</span></div> <div class="stat-item svelte-11vrnrd"><span class="stat-value svelte-11vrnrd"> </span> <span class="stat-label svelte-11vrnrd">Gesendet</span></div></div>'),Zd=T("<!> <!> <!>",1),Qd=T("<!> <!>",1);function Xd(r,e){we(e,!1);const[t,s]=qn(),n=()=>jn(Xn,"$bridgeRequestStore",t),i=ee();let a=ee(null),o=ee(!1);const l=[{key:"id",value:"Anfrage-ID"},{key:"projectName",value:"Projekt"},{key:"company",value:"Firma"},{key:"structureType",value:"Bauwerkstyp"},{key:"date",value:"Datum"},{key:"status",value:"Status"}];function u(C){return new Date(C).toLocaleDateString("de-DE",{year:"numeric",month:"2-digit",day:"2-digit"})}function m(C){switch(C){case"Gesendet":return"green";case"Entwurf":return"gray";default:return"gray"}}function p(C){$(a,n().find(I=>I.id===C)||null),c(a)&&$(o,!0)}ne(()=>n(),()=>{$(i,n().map(C=>({id:C.id,projectName:C.data.projectName||"-",company:C.data.company||"-",structureType:C.data.structureType||"-",date:u(C.createdAt),status:"Gesendet"})))}),De(),Re();var d=Qd(),_=q(d);At(_,{backLabel:"",actionLabel:"Neue Anfrage",children:(C,I)=>{var w=Zd(),S=q(w);Se(S,{children:(b,j)=>{se(b,{lg:16,children:(V,H)=>{var A=Gd();W(2),v(V,A)},$$slots:{default:!0}})},$$slots:{default:!0}});var M=g(S,2);Se(M,{children:(b,j)=>{se(b,{children:(V,H)=>{var A=ze(),k=q(A);{var B=F=>{Vs(F,{get headers(){return l},get rows(){return c(i)},$$slots:{cell:(L,x)=>{const z=ae(()=>x.cell),fe=ae(()=>x.row);var ye=ze(),J=q(ye);{var te=de=>{const X=ae(()=>m(c(z).value));Zt(de,{get type(){return c(X)},children:(ve,Te)=>{W();var Pe=ce();R(()=>P(Pe,c(z).value)),v(ve,Pe)},$$slots:{default:!0}})},le=(de,X)=>{{var ve=Pe=>{var pe=Kd(),xe=f(pe);h(pe),R(_e=>P(xe,`${_e??""}...`),[()=>c(z).value.substring(0,8)],ae),oe("click",pe,()=>p(c(fe).id)),v(Pe,pe)},Te=Pe=>{var pe=ce();R(()=>P(pe,c(z).value)),v(Pe,pe)};N(de,Pe=>{c(z).key==="id"?Pe(ve):Pe(Te,!1)},X)}};N(J,de=>{c(z).key==="status"?de(te):de(le,!1)})}v(L,ye)}}})},U=F=>{var L=Yd();v(F,L)};N(k,F=>{c(i).length>0?F(B):F(U,!1)})}v(V,A)},$$slots:{default:!0}})},$$slots:{default:!0}});var O=g(M,2);Se(O,{children:(b,j)=>{se(b,{children:(V,H)=>{var A=Jd(),k=f(A),B=f(k),U=f(B,!0);h(B),W(2),h(k);var F=g(k,2),L=f(F),x=f(L,!0);h(L),W(2),h(F),h(A),R(()=>{P(U,n().length),P(x,n().length)}),v(V,A)},$$slots:{default:!0}})},$$slots:{default:!0}}),v(C,w)},$$slots:{default:!0}});var y=g(_,2);qd(y,{get request(){return c(a)},get open(){return c(o)},set open(C){$(o,C)},$$legacy:!0}),v(r,d),Ie(),s()}var eu=T('<h1 class="page-title svelte-16epnr2">My Quotes</h1> <p class="page-subtitle svelte-16epnr2">Manage and track your quotations</p>',1),tu=T('<p class="summary-value svelte-16epnr2">$66,450</p> <p class="summary-label svelte-16epnr2">Total Quoted Value</p>',1),ru=T('<p class="summary-value svelte-16epnr2">2</p> <p class="summary-label svelte-16epnr2">Active Quotes</p>',1),su=T('<p class="summary-value svelte-16epnr2">45%</p> <p class="summary-label svelte-16epnr2">Acceptance Rate</p>',1),nu=T('<p class="summary-value svelte-16epnr2">7 days</p> <p class="summary-label svelte-16epnr2">Avg. Response Time</p>',1),iu=T("<!> <!> <!> <!>",1),au=T('<a href="#" class="quote-link svelte-16epnr2"> </a>'),ou=T("<strong> </strong>"),lu=T("<!> <!> <!>",1);function cu(r){const e=[{id:"QT-2023-001",customer:"LUMBER COMPANY",total:"$12,450.00",items:8,date:"2023-06-20",expires:"2023-07-20",status:"Active"},{id:"QT-2023-002",customer:"TIMBER DEPOT",total:"$8,320.00",items:5,date:"2023-06-18",expires:"2023-07-18",status:"Active"},{id:"QT-2023-003",customer:"WOODWORKS INC",total:"$24,100.00",items:12,date:"2023-06-15",expires:"2023-07-15",status:"Accepted"},{id:"QT-2023-004",customer:"FOREST SUPPLIES",total:"$5,680.00",items:3,date:"2023-06-10",expires:"2023-07-10",status:"Expired"},{id:"QT-2023-005",customer:"PINE TRADERS",total:"$15,900.00",items:7,date:"2023-06-08",expires:"2023-07-08",status:"Declined"}],t=[{key:"id",value:"Quote #"},{key:"customer",value:"Customer"},{key:"items",value:"Items"},{key:"total",value:"Total"},{key:"date",value:"Created"},{key:"expires",value:"Expires"},{key:"status",value:"Status"}];function s(n){switch(n){case"Active":return"blue";case"Accepted":return"green";case"Expired":return"gray";case"Declined":return"red";default:return"gray"}}At(r,{backLabel:"",actionLabel:"Create Quote",children:(n,i)=>{var a=lu(),o=q(a);Se(o,{children:(m,p)=>{se(m,{lg:16,children:(d,_)=>{var y=eu();W(2),v(d,y)},$$slots:{default:!0}})},$$slots:{default:!0}});var l=g(o,2);Se(l,{children:(m,p)=>{var d=iu(),_=q(d);se(_,{lg:4,md:4,sm:4,children:(w,S)=>{Le(w,{class:"summary-tile",children:(M,O)=>{var b=tu();W(2),v(M,b)},$$slots:{default:!0}})},$$slots:{default:!0}});var y=g(_,2);se(y,{lg:4,md:4,sm:4,children:(w,S)=>{Le(w,{class:"summary-tile",children:(M,O)=>{var b=ru();W(2),v(M,b)},$$slots:{default:!0}})},$$slots:{default:!0}});var C=g(y,2);se(C,{lg:4,md:4,sm:4,children:(w,S)=>{Le(w,{class:"summary-tile",children:(M,O)=>{var b=su();W(2),v(M,b)},$$slots:{default:!0}})},$$slots:{default:!0}});var I=g(C,2);se(I,{lg:4,md:4,sm:4,children:(w,S)=>{Le(w,{class:"summary-tile",children:(M,O)=>{var b=nu();W(2),v(M,b)},$$slots:{default:!0}})},$$slots:{default:!0}}),v(m,d)},$$slots:{default:!0}});var u=g(l,2);Se(u,{children:(m,p)=>{se(m,{children:(d,_)=>{Vs(d,{get headers(){return t},get rows(){return e},$$slots:{cell:(y,C)=>{const I=ae(()=>C.cell);var w=ze(),S=q(w);{var M=b=>{const j=ae(()=>s(c(I).value));Zt(b,{get type(){return c(j)},children:(V,H)=>{W();var A=ce();R(()=>P(A,c(I).value)),v(V,A)},$$slots:{default:!0}})},O=(b,j)=>{{var V=A=>{var k=au(),B=f(k,!0);h(k),R(()=>P(B,c(I).value)),v(A,k)},H=(A,k)=>{{var B=F=>{var L=ou(),x=f(L,!0);h(L),R(()=>P(x,c(I).value)),v(F,L)},U=F=>{var L=ce();R(()=>P(L,c(I).value)),v(F,L)};N(A,F=>{c(I).key==="total"?F(B):F(U,!1)},k)}};N(b,A=>{c(I).key==="id"?A(V):A(H,!1)},j)}};N(S,b=>{c(I).key==="status"?b(M):b(O,!1)})}v(y,w)}}})},$$slots:{default:!0}})},$$slots:{default:!0}}),v(n,a)},$$slots:{default:!0}})}var du=ke("<title> </title>"),uu=ke('<svg><!><circle cx="22" cy="24" r="2"></circle><path fill="none" d="M22,28a4,4,0,1,1,4-4A4.0039,4.0039,0,0,1,22,28Zm0-6a2,2,0,1,0,2,2A2.0027,2.0027,0,0,0,22,22Z"></path><path d="M29.7769,23.4785A8.64,8.64,0,0,0,22,18a8.64,8.64,0,0,0-7.7769,5.4785L14,24l.2231.5215A8.64,8.64,0,0,0,22,30a8.64,8.64,0,0,0,7.7769-5.4785L30,24ZM22,28a4,4,0,1,1,4-4A4.0045,4.0045,0,0,1,22,28Z"></path><path d="M12,28H8V4h8v6a2.0058,2.0058,0,0,0,2,2h6v4h2V10a.9092.9092,0,0,0-.3-.7l-7-7A.9087.9087,0,0,0,18,2H8A2.0058,2.0058,0,0,0,6,4V28a2.0058,2.0058,0,0,0,2,2h4ZM18,4.4,23.6,10H18Z"></path></svg>');function hu(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=uu();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=du(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(4),h(l),v(r,l),Ie()}var fu=ke("<title> </title>"),vu=ke('<svg><!><path d="M2 28H30V30H2zM17.21 5.23l1.39.38 1 11.29 5.87 1.57A2 2 0 0127 20.62a1.88 1.88 0 01-1.37 1.52 2 2 0 01-1 0l-18.7-5a1.89 1.89 0 01-1.33-2.3L6.35 8.34l1.44.38L8.4 13.9l6 1.62L17.21 5.23m-1-2.2a1 1 0 00-.68.69L13 13.07l-2.81-.75L9.69 7.79A1 1 0 009 7L5.87 6.14a.94.94 0 00-.5 0 1 1 0 00-.68.68l-2 7.49a3.87 3.87 0 002.74 4.74l18.71 5A3.87 3.87 0 0029 21a4 4 0 00-3-4.42l-4.52-1.21L20.53 4.71a1 1 0 00-.72-.85L16.73 3a1.06 1.06 0 00-.5 0z"></path></svg>');function pu(r,e){const t=Q(e,["children","$$slots","$$events","$$legacy"]),s=Q(t,["size","title"]);we(e,!1);const n=ee(),i=ee();let a=E(e,"size",8,16),o=E(e,"title",8,void 0);ne(()=>(K(t),K(o())),()=>{$(n,t["aria-label"]||t["aria-labelledby"]||o())}),ne(()=>(c(n),K(t)),()=>{$(i,{"aria-hidden":c(n)?void 0:!0,role:c(n)?"img":void 0,focusable:Number(t.tabindex)===0?!0:void 0})}),De(),Re();var l=vu();$e(l,()=>({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 32 32",fill:"currentColor",preserveAspectRatio:"xMidYMid meet",width:a(),height:a(),...c(i),...s}));var u=f(l);{var m=p=>{var d=fu(),_=f(d,!0);h(d),R(()=>P(_,o())),v(p,d)};N(u,p=>{o()&&p(m)})}W(),h(l),v(r,l),Ie()}var gu=T('<div class="timeline-line svelte-1x7wtir"></div>'),mu=T('<div class="timeline-step svelte-1x7wtir"><p class="step-label svelte-1x7wtir"> </p> <div><!></div> <p class="step-date svelte-1x7wtir"> </p></div> <!>',1),_u=T('<div class="timeline-wrapper svelte-1x7wtir"><div class="timeline-container svelte-1x7wtir"></div></div>');function bu(r,e){we(e,!0);var t=_u(),s=f(t);kt(s,21,()=>e.steps,Lt,(n,i,a)=>{var o=mu(),l=q(o),u=f(l),m=f(u,!0);h(u);var p=g(u,2);let d;var _=f(p);dr(_,()=>c(i).icon,(S,M)=>{M(S,{size:24,fill:"white"})}),h(p);var y=g(p,2),C=f(y,!0);h(y),h(l);var I=g(l,2);{var w=S=>{var M=gu();v(S,M)};N(I,S=>{a<e.steps.length-1&&S(w)})}R(S=>{P(m,c(i).label),d=Ae(p,1,"icon-box svelte-1x7wtir",null,d,S),P(C,c(i).date)},[()=>({active:c(i).active!==!1})]),v(n,o)}),h(s),h(t),v(r,t),Ie()}var yu=T('<div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Ship-To</p> <p class="value svelte-y39ibg"> </p></div> <div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Sales Order #</p> <p class="value svelte-y39ibg"> </p></div>',1),wu=T('<div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Status</p> <p class="value status-complete svelte-y39ibg"><span class="dot">●</span> </p></div> <div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Account Manager</p> <p class="value svelte-y39ibg"> </p></div>',1),Iu=T('<div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Customer PO#</p> <p class="value svelte-y39ibg"> </p></div> <div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Linked Purchase Order #</p> <p class="value svelte-y39ibg"> </p></div>',1),Eu=T('<div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Payment Terms</p> <p class="value svelte-y39ibg"> </p></div> <div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Ship Terms</p> <p class="value svelte-y39ibg"> </p></div>',1),Tu=T('<div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Amount</p> <p class="value svelte-y39ibg">Total Sales <span class="highlight svelte-y39ibg"> </span> <br/>Value:</p></div> <div class="field svelte-y39ibg"><p class="label svelte-y39ibg">Paid in Full</p> <p class="value svelte-y39ibg"> </p></div>',1),Pu=T("<!> <!> <!> <!> <!>",1),xu=T('<p class="label svelte-y39ibg">Port of Loading</p> <p class="value uppercase svelte-y39ibg"> </p>',1),ku=T('<p class="label svelte-y39ibg">Shipping Line</p> <p class="value uppercase svelte-y39ibg"> </p>',1),Au=T('<p class="label svelte-y39ibg">Equipment No(s)</p> <p class="value svelte-y39ibg"> </p>',1),Su=T('<p class="label svelte-y39ibg">BL/Waybill No</p> <p class="value svelte-y39ibg"> </p>',1),Cu=T("<!> <!> <!> <!>",1),$u=T('<div class="card-section header-section svelte-y39ibg"><p class="label svelte-y39ibg">Customer</p> <h3> </h3></div> <hr class="divider svelte-y39ibg"/> <div class="card-section details-grid svelte-y39ibg"><!></div> <hr class="divider svelte-y39ibg"/> <!> <hr class="divider svelte-y39ibg"/> <div class="card-section footer-info svelte-y39ibg"><!></div>',1);function Ru(r,e){we(e,!0);const t=Ns(()=>[{label:"Order Placed",date:e.order.timeline.orderPlaced,icon:hu,active:!0},{label:"ETS",date:e.order.timeline.ets,icon:zs,active:!0},{label:"ETA",date:e.order.timeline.eta,icon:pu,active:!0}]);Le(r,{class:"order-card",children:(s,n)=>{var i=$u(),a=q(i),o=g(f(a),2),l=f(o,!0);h(o),h(a);var u=g(a,4),m=f(u);rs(m,{fullWidth:!0,padding:!0,children:(y,C)=>{Se(y,{children:(I,w)=>{var S=Pu(),M=q(S);se(M,{sm:4,md:2,lg:3,children:(H,A)=>{var k=yu(),B=q(k),U=g(f(B),2),F=f(U,!0);h(U),h(B);var L=g(B,2),x=g(f(L),2),z=f(x,!0);h(x),h(L),R(()=>{P(F,e.order.shipTo),P(z,e.order.salesOrderNumber)}),v(H,k)},$$slots:{default:!0}});var O=g(M,2);se(O,{sm:4,md:2,lg:3,children:(H,A)=>{var k=wu(),B=q(k),U=g(f(B),2),F=g(f(U));h(U),h(B);var L=g(B,2),x=g(f(L),2),z=f(x,!0);h(x),h(L),R(()=>{P(F,` ${e.order.status??""}`),P(z,e.order.accountManager)}),v(H,k)},$$slots:{default:!0}});var b=g(O,2);se(b,{sm:4,md:2,lg:3,children:(H,A)=>{var k=Iu(),B=q(k),U=g(f(B),2),F=f(U,!0);h(U),h(B);var L=g(B,2),x=g(f(L),2),z=f(x,!0);h(x),h(L),R(()=>{P(F,e.order.customerPO),P(z,e.order.linkedPurchaseOrder||"—")}),v(H,k)},$$slots:{default:!0}});var j=g(b,2);se(j,{sm:4,md:2,lg:3,children:(H,A)=>{var k=Eu(),B=q(k),U=g(f(B),2),F=f(U,!0);h(U),h(B);var L=g(B,2),x=g(f(L),2),z=f(x,!0);h(x),h(L),R(()=>{P(F,e.order.paymentTerms),P(z,e.order.shipTerms)}),v(H,k)},$$slots:{default:!0}});var V=g(j,2);se(V,{sm:4,md:2,lg:4,children:(H,A)=>{var k=Tu(),B=q(k),U=g(f(B),2),F=g(f(U)),L=f(F,!0);h(F),W(3),h(U),h(B);var x=g(B,2),z=g(f(x),2),fe=f(z,!0);h(z),h(x),R(()=>{P(L,e.order.totalSales),P(fe,e.order.paidInFull?"Yes":"No")}),v(H,k)},$$slots:{default:!0}}),v(I,S)},$$slots:{default:!0}})},$$slots:{default:!0}}),h(u);var p=g(u,4);bu(p,{get steps(){return c(t)}});var d=g(p,4),_=f(d);rs(_,{fullWidth:!0,padding:!0,children:(y,C)=>{Se(y,{children:(I,w)=>{var S=Cu(),M=q(S);se(M,{sm:4,md:2,lg:3,children:(V,H)=>{var A=xu(),k=g(q(A),2),B=f(k,!0);h(k),R(()=>P(B,e.order.portOfLoading)),v(V,A)},$$slots:{default:!0}});var O=g(M,2);se(O,{sm:4,md:3,lg:4,children:(V,H)=>{var A=ku(),k=g(q(A),2),B=f(k,!0);h(k),R(()=>P(B,e.order.shippingLine)),v(V,A)},$$slots:{default:!0}});var b=g(O,2);se(b,{sm:4,md:2,lg:3,children:(V,H)=>{var A=Au(),k=g(q(A),2),B=f(k,!0);h(k),R(()=>P(B,e.order.equipmentNumbers||"—")),v(V,A)},$$slots:{default:!0}});var j=g(b,2);se(j,{sm:4,md:2,lg:2,children:(V,H)=>{var A=Su(),k=g(q(A),2),B=f(k,!0);h(k),R(()=>P(B,e.order.blWaybillNo||"—")),v(V,A)},$$slots:{default:!0}}),v(I,S)},$$slots:{default:!0}})},$$slots:{default:!0}}),h(d),R(()=>P(l,e.order.customer)),v(s,i)},$$slots:{default:!0}}),Ie()}function Ou(r){const e={customer:"LUMBER COMPANY",shipTo:"TIMBER DEPOT",salesOrderNumber:"27041941",status:"Complete",accountManager:"Joseph Campbell",customerPO:"23008223",linkedPurchaseOrder:"",paymentTerms:"1% 75 DAYS N76 ADI/ADF",shipTerms:"CIP - CASTRIES",totalSales:"$64,855.10",paidInFull:!1,portOfLoading:"MOBILE",shippingLine:"OSLO CARIBBEAN CARRIERS",equipmentNumbers:"",blWaybillNo:"",timeline:{orderPlaced:"21 Jun 2023",ets:"25 Aug 2023",eta:"27 Jul 2023"}};At(r,{backLabel:"BACK",actionLabel:"FOLLOW ORDER",children:(t,s)=>{Se(t,{children:(n,i)=>{se(n,{children:(a,o)=>{Ru(a,{get order(){return e}})},$$slots:{default:!0}})},$$slots:{default:!0}})},$$slots:{default:!0}})}var Mu=T('<h1 class="page-title svelte-19wt0gl">My Products</h1> <p class="page-subtitle svelte-19wt0gl">Manage your product inventory</p>',1),Du=T('<div class="product-image svelte-19wt0gl"><span class="product-icon svelte-19wt0gl">🪵</span></div> <div class="product-info svelte-19wt0gl"><h4 class="product-name svelte-19wt0gl"> </h4> <p class="product-category svelte-19wt0gl"> </p> <div class="product-details svelte-19wt0gl"><span class="product-price svelte-19wt0gl"> </span> <!></div> <p class="product-stock svelte-19wt0gl"> </p> <div class="product-actions svelte-19wt0gl"><!> <!></div></div>',1),Nu=T("<!> <!> <!>",1);function Lu(r){const e=[{id:"PRD-001",name:"Pine Lumber 2x4",category:"Lumber",price:"$4.50/pc",stock:1250,status:"In Stock"},{id:"PRD-002",name:"Oak Planks Premium",category:"Hardwood",price:"$12.00/sqft",stock:450,status:"In Stock"},{id:"PRD-003",name:"Cedar Shingles",category:"Roofing",price:"$2.25/pc",stock:3200,status:"In Stock"},{id:"PRD-004",name:"Maple Flooring",category:"Flooring",price:"$8.75/sqft",stock:85,status:"Low Stock"},{id:"PRD-005",name:'Birch Plywood 3/4"',category:"Plywood",price:"$45.00/sheet",stock:0,status:"Out of Stock"},{id:"PRD-006",name:"Walnut Veneer",category:"Veneer",price:"$6.50/sqft",stock:620,status:"In Stock"}];function t(s){switch(s){case"In Stock":return"green";case"Low Stock":return"cyan";case"Out of Stock":return"red";default:return"gray"}}At(r,{backLabel:"",actionLabel:"Add Product",children:(s,n)=>{var i=Nu(),a=q(i);Se(a,{children:(u,m)=>{se(u,{lg:16,children:(p,d)=>{var _=Mu();W(2),v(p,_)},$$slots:{default:!0}})},$$slots:{default:!0}});var o=g(a,2);Se(o,{children:(u,m)=>{se(u,{lg:8,children:(p,d)=>{Vr(p,{placeholder:"Search products..."})},$$slots:{default:!0}})},$$slots:{default:!0}});var l=g(o,2);Se(l,{children:(u,m)=>{var p=ze(),d=q(p);kt(d,1,()=>e,Lt,(_,y)=>{se(_,{lg:5,md:4,sm:4,children:(C,I)=>{Le(C,{class:"product-card",children:(w,S)=>{var M=Du(),O=g(q(M),2),b=f(O),j=f(b,!0);h(b);var V=g(b,2),H=f(V,!0);h(V);var A=g(V,2),k=f(A),B=f(k,!0);h(k);var U=g(k,2);const F=ae(()=>t(c(y).status));Zt(U,{get type(){return c(F)},size:"sm",children:(J,te)=>{W();var le=ce();R(()=>P(le,c(y).status)),v(J,le)},$$slots:{default:!0}}),h(A);var L=g(A,2),x=f(L);h(L);var z=g(L,2),fe=f(z);st(fe,{kind:"ghost",size:"small",children:(J,te)=>{W();var le=ce("Edit");v(J,le)},$$slots:{default:!0}});var ye=g(fe,2);st(ye,{kind:"ghost",size:"small",children:(J,te)=>{W();var le=ce("View");v(J,le)},$$slots:{default:!0}}),h(z),h(O),R(()=>{P(j,c(y).name),P(H,c(y).category),P(B,c(y).price),P(x,`Stock: ${c(y).stock??""} units`)}),v(w,M)},$$slots:{default:!0}})},$$slots:{default:!0}})}),v(u,p)},$$slots:{default:!0}}),v(s,i)},$$slots:{default:!0}})}var Uu=T('<h1 class="page-title svelte-yyu2p6">Catalogue</h1> <p class="page-subtitle svelte-yyu2p6">Browse our complete product catalogue</p>',1),Hu=T("<!> <!>",1),Bu=T('<div class="catalogue-header svelte-yyu2p6"><span class="results-count svelte-yyu2p6"> </span></div>'),Vu=T('<div class="catalogue-image svelte-yyu2p6"><span class="catalogue-icon svelte-yyu2p6">📦</span></div> <div class="catalogue-info svelte-yyu2p6"><!> <h4 class="catalogue-name svelte-yyu2p6"> </h4> <p class="catalogue-price svelte-yyu2p6"> </p> <div class="catalogue-meta svelte-yyu2p6"><p class="svelte-yyu2p6"> </p> <p class="svelte-yyu2p6"> </p></div> <div class="catalogue-actions svelte-yyu2p6"><!> <!></div></div>',1),zu=T('<div class="pagination svelte-yyu2p6"><!> <span class="page-info svelte-yyu2p6">Page 1 of 3</span> <!></div>'),Fu=T("<!> <!> <!> <!> <!>",1);function Wu(r){const e=[{id:"all",text:"All Categories"},{id:"lumber",text:"Lumber"},{id:"hardwood",text:"Hardwood"},{id:"plywood",text:"Plywood"},{id:"flooring",text:"Flooring"},{id:"roofing",text:"Roofing"}],t=[{id:"CAT-001",name:"Douglas Fir 2x6",category:"Lumber",price:"$6.25/pc",minOrder:"100 pcs",leadTime:"3-5 days"},{id:"CAT-002",name:"White Oak Boards",category:"Hardwood",price:"$14.50/sqft",minOrder:"50 sqft",leadTime:"5-7 days"},{id:"CAT-003",name:"Baltic Birch Plywood",category:"Plywood",price:"$52.00/sheet",minOrder:"10 sheets",leadTime:"7-10 days"},{id:"CAT-004",name:"Brazilian Cherry Flooring",category:"Flooring",price:"$11.25/sqft",minOrder:"100 sqft",leadTime:"10-14 days"},{id:"CAT-005",name:"Western Red Cedar",category:"Lumber",price:"$8.75/pc",minOrder:"50 pcs",leadTime:"3-5 days"},{id:"CAT-006",name:"Ash Hardwood",category:"Hardwood",price:"$9.00/sqft",minOrder:"75 sqft",leadTime:"5-7 days"},{id:"CAT-007",name:"Marine Grade Plywood",category:"Plywood",price:"$68.00/sheet",minOrder:"5 sheets",leadTime:"7-10 days"},{id:"CAT-008",name:"Bamboo Flooring",category:"Flooring",price:"$7.50/sqft",minOrder:"150 sqft",leadTime:"7-10 days"}];let s=ee("all");At(r,{backLabel:"",actionLabel:"Request Quote",children:(n,i)=>{var a=Fu(),o=q(a);Se(o,{children:(d,_)=>{se(d,{lg:16,children:(y,C)=>{var I=Uu();W(2),v(y,I)},$$slots:{default:!0}})},$$slots:{default:!0}});var l=g(o,2);Se(l,{children:(d,_)=>{var y=Hu(),C=q(y);se(C,{lg:8,md:4,sm:4,children:(w,S)=>{Vr(w,{placeholder:"Search catalogue..."})},$$slots:{default:!0}});var I=g(C,2);se(I,{lg:4,md:4,sm:4,children:(w,S)=>{_i(w,{titleText:"",get items(){return e},get selectedId(){return c(s)},set selectedId(M){$(s,M)},$$legacy:!0})},$$slots:{default:!0}}),v(d,y)},$$slots:{default:!0}});var u=g(l,2);Se(u,{children:(d,_)=>{se(d,{lg:16,children:(y,C)=>{var I=Bu(),w=f(I),S=f(w);h(w),h(I),R(()=>P(S,`${t.length??""} products found`)),v(y,I)},$$slots:{default:!0}})},$$slots:{default:!0}});var m=g(u,2);Se(m,{children:(d,_)=>{var y=ze(),C=q(y);kt(C,1,()=>t,Lt,(I,w)=>{se(I,{lg:4,md:4,sm:4,children:(S,M)=>{Le(S,{class:"catalogue-card",children:(O,b)=>{var j=Vu(),V=g(q(j),2),H=f(V);Zt(H,{type:"outline",size:"sm",children:(le,de)=>{W();var X=ce();R(()=>P(X,c(w).category)),v(le,X)},$$slots:{default:!0}});var A=g(H,2),k=f(A,!0);h(A);var B=g(A,2),U=f(B,!0);h(B);var F=g(B,2),L=f(F),x=f(L);h(L);var z=g(L,2),fe=f(z);h(z),h(F);var ye=g(F,2),J=f(ye);st(J,{kind:"primary",size:"small",children:(le,de)=>{W();var X=ce("Add to Quote");v(le,X)},$$slots:{default:!0}});var te=g(J,2);st(te,{kind:"ghost",size:"small",children:(le,de)=>{W();var X=ce("Details");v(le,X)},$$slots:{default:!0}}),h(ye),h(V),R(()=>{P(k,c(w).name),P(U,c(w).price),P(x,`Min: ${c(w).minOrder??""}`),P(fe,`Lead: ${c(w).leadTime??""}`)}),v(O,j)},$$slots:{default:!0}})},$$slots:{default:!0}})}),v(d,y)},$$slots:{default:!0}});var p=g(m,2);Se(p,{children:(d,_)=>{se(d,{children:(y,C)=>{var I=zu(),w=f(I);st(w,{kind:"ghost",size:"small",disabled:!0,children:(M,O)=>{W();var b=ce("Previous");v(M,b)},$$slots:{default:!0}});var S=g(w,4);st(S,{kind:"ghost",size:"small",children:(M,O)=>{W();var b=ce("Next");v(M,b)},$$slots:{default:!0}}),h(I),v(y,I)},$$slots:{default:!0}})},$$slots:{default:!0}}),v(n,a)},$$slots:{default:!0}})}var ju=T('<div class="loading-container svelte-2g7l8z"><div class="loading-spinner svelte-2g7l8z"></div></div>'),qu=T('<div class="dashboard-container svelte-2g7l8z"><div><!> <div class="content-area svelte-2g7l8z"><!></div></div></div>');function Gu(r,e){we(e,!0);let t=qe(!0),s=qe("dashboard"),n=qe(null),i=qe(!0);Ms(()=>{const I=tc(qt,w=>{$(n,w,!0),$(i,!1)});return()=>I()});function a(I){$(s,I,!0)}async function o(){await rc(qt)}var l=qu(),u=f(l);let m;var p=f(u);da(p,{get activeItem(){return c(s)},onNavigate:a,get user(){return c(n)},onLogout:o,get isOpen(){return c(t)},set isOpen(I){$(t,I,!0)}});var d=g(p,2),_=f(d);{var y=I=>{var w=ju();v(I,w)},C=(I,w)=>{{var S=O=>{wd(O,{})},M=(O,b)=>{{var j=H=>{Os(H)},V=(H,A)=>{{var k=U=>{Hd(U)},B=(U,F)=>{{var L=z=>{Xd(z,{})},x=(z,fe)=>{{var ye=te=>{cu(te)},J=(te,le)=>{{var de=ve=>{Ou(ve)},X=(ve,Te)=>{{var Pe=xe=>{Lu(xe)},pe=(xe,_e)=>{{var Fe=re=>{Wu(re)},ue=re=>{Os(re)};N(xe,re=>{c(s)==="catalogue"?re(Fe):re(ue,!1)},_e)}};N(ve,xe=>{c(s)==="products"?xe(Pe):xe(pe,!1)},Te)}};N(te,ve=>{c(s)==="orders"?ve(de):ve(X,!1)},le)}};N(z,te=>{c(s)==="quotes"?te(ye):te(J,!1)},fe)}};N(U,z=>{c(s)==="requests"?z(L):z(x,!1)},F)}};N(H,U=>{c(s)==="chats"?U(k):U(B,!1)},A)}};N(O,H=>{c(s)==="dashboard"?H(j):H(V,!1)},b)}};N(I,O=>{c(n)?O(M,!1):O(S)},w)}};N(_,I=>{c(i)?I(y):I(C,!1)})}h(d),h(u),h(l),R(I=>m=Ae(u,1,"layout svelte-2g7l8z",null,m,I),[()=>({"sidebar-open":c(t)})]),v(r,l),Ie()}function vh(r){Gu(r,{})}export{vh as component,fh as universal};
