import{a as e,_ as n}from"../chunks/OblmjEr5.js";export{e as component,n as universal};
