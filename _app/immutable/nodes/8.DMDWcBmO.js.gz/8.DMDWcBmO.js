import{a as e,_ as n}from"../chunks/CebOLmnC.js";export{e as component,n as universal};
