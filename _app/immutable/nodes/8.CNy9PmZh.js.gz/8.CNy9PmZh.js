import{a as e,_ as n}from"../chunks/pTb2KLvn.js";export{e as component,n as universal};
