import{c as e,a as n}from"../chunks/BfAgE50s.js";export{e as component,n as universal};
