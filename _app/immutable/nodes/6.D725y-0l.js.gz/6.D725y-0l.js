import{a as e,_ as n}from"../chunks/Bd1BVrwR.js";export{e as component,n as universal};
