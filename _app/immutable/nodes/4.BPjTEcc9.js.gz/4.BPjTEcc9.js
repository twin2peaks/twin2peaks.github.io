import{a as e,_ as n}from"../chunks/BDEOXT_I.js";export{e as component,n as universal};
