import{a as e,_ as n}from"../chunks/0VSHVk5S.js";export{e as component,n as universal};
