import{a as e,_ as n}from"../chunks/B5flqkOH.js";export{e as component,n as universal};
