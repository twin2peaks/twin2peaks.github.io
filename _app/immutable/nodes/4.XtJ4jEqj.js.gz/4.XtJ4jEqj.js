import{a as e,_ as n}from"../chunks/DjReblxd.js";export{e as component,n as universal};
