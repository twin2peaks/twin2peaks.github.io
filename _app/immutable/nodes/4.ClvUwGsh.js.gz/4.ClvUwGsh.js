import{a as e,_ as n}from"../chunks/BoQ6ED6p.js";export{e as component,n as universal};
