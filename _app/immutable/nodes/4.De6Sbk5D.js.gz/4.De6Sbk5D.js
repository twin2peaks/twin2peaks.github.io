import{a as e,_ as n}from"../chunks/DT3KskKG.js";export{e as component,n as universal};
