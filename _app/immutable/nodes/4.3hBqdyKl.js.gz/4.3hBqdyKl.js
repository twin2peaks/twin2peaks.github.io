import{a as e,_ as n}from"../chunks/D6O2swiA.js";export{e as component,n as universal};
