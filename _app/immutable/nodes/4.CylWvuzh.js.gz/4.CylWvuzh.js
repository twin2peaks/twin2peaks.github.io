import{a as e,_ as n}from"../chunks/BeRkwEpq.js";export{e as component,n as universal};
