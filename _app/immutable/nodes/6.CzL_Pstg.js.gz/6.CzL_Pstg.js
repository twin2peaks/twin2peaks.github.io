import{a as e,_ as n}from"../chunks/Dkpir9wp.js";export{e as component,n as universal};
