import{c as e,a as n}from"../chunks/JOOfQj-y.js";export{e as component,n as universal};
