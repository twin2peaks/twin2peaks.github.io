import{a as e,_ as n}from"../chunks/CG4qLlAn.js";export{e as component,n as universal};
