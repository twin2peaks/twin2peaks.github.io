var s;const a=((s=globalThis.__sveltekit_1s69spj)==null?void 0:s.base)??"/twin2peaks.github.io";var t;const e=((t=globalThis.__sveltekit_1s69spj)==null?void 0:t.assets)??a??"";export{e as a,a as b};
