const s=globalThis.__sveltekit_1ia9sdt?.base??"",a=globalThis.__sveltekit_1ia9sdt?.assets??s??"";export{a,s as b};
