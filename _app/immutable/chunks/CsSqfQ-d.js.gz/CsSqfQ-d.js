const s=globalThis.__sveltekit_xuajwc?.base??"",a=globalThis.__sveltekit_xuajwc?.assets??s??"";export{a,s as b};
