import{C as t}from"./CBi1G5YP.js";function b(e,r){var a=e.$$events?.[r.type],l=t(a)?a.slice():a==null?[]:[a];for(var s of l)s.call(this,r)}export{b};
