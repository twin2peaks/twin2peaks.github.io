const t="https://twin2peaks.github.io/";export{t as B};
