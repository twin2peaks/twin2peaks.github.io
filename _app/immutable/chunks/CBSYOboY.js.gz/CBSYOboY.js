import{k as o,E as f,o as i,q as p,u as c,v as d,w as h}from"./CBZ1_ELx.js";function v(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{v as s};
