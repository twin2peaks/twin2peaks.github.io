const s=globalThis.__sveltekit_rebe2b?.base??"",e=globalThis.__sveltekit_rebe2b?.assets??s??"";export{e as a,s as b};
