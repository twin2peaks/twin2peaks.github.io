const s=globalThis.__sveltekit_1cj2f5e?.base??"",e=globalThis.__sveltekit_1cj2f5e?.assets??s??"";export{e as a,s as b};
