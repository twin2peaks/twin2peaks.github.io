import{A as t}from"./rdat2yet.js";function b(e,r){var a=e.$$events?.[r.type],l=t(a)?a.slice():a==null?[]:[a];for(var s of l)s.call(this,r)}export{b};
