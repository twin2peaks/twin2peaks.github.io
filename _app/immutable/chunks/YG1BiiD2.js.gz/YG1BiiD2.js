const s=globalThis.__sveltekit_1brxcxd?.base??"",a=globalThis.__sveltekit_1brxcxd?.assets??s??"";export{a,s as b};
