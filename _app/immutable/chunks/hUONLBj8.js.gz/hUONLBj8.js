import{R as o,H as e}from"./D0iwhpLH.js";function i(r,t){throw new e(r,t)}function a(r,t){throw new o(r,t.toString())}export{i as e,a as r};
