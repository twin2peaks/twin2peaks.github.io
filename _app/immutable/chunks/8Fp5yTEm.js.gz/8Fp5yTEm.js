import{b as o,E as f,a as i,n as p,d as c,h as d,c as h}from"./BhId24Go.js";function _(s,e,...t){var r=s,n=p,a;o(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=i(()=>n(r,...t)))},f),d&&(r=h)}export{_ as s};
