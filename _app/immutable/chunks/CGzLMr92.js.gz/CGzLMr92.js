import{v as o,E as f,w as i,x as p,y as c,q as d,z as h}from"./CBi1G5YP.js";function y(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{y as s};
