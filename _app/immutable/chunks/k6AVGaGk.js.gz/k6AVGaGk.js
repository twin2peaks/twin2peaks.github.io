const s=globalThis.__sveltekit_dczk1i?.base??"",a=globalThis.__sveltekit_dczk1i?.assets??s??"";export{a,s as b};
