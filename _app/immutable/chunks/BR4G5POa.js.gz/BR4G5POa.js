const s=globalThis.__sveltekit_sdqn2y?.base??"",a=globalThis.__sveltekit_sdqn2y?.assets??s??"";export{a,s as b};
