import{l as o,a as r}from"../chunks/CB7a4NwC.js";export{o as load_css,r as start};
