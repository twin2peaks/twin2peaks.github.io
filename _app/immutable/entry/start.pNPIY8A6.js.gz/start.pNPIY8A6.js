import{l as o,a as r}from"../chunks/CDs_p-Bj.js";export{o as load_css,r as start};
