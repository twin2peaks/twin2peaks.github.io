import{l as o,a as r}from"../chunks/C4_fU92w.js";export{o as load_css,r as start};
