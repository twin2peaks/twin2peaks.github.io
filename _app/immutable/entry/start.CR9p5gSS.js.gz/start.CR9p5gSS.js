import{l as o,a as r}from"../chunks/BI-KVtUh.js";export{o as load_css,r as start};
